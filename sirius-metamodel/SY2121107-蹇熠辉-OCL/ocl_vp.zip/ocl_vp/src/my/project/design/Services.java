package my.project.design;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

import ocl_final.BasicElement;
import ocl_final.IfExpression;
import ocl_final.OCL;
import ocl_final.Ocl_finalFactory;
import ocl_final.Operation;

/**
 * The services class used by VSM.
 */
public class Services {
    
    /**
    * See http://help.eclipse.org/neon/index.jsp?topic=%2Forg.eclipse.sirius.doc%2Fdoc%2Findex.html&cp=24 for documentation on how to write service methods.
    */
    public EObject myService(EObject self, String arg) {
       // TODO Auto-generated code
      return self;
    }
    
    public void addNewConjunction(EObject self, Operation o1, Operation o2) {
    	var conj = Ocl_finalFactory.eINSTANCE.createConjunction();

    	((OCL)o1.eContainer()).getBasicelement().add(conj);
    	conj.setPrev(o1);
    	conj.setNext(o2);

    }
    
    public void addNewConditionThenElse(EObject self, IfExpression o1, Operation o2) {
    	var condition = Ocl_finalFactory.eINSTANCE.createCondition();

    	((OCL)o1.eContainer()).getBasicelement().add((BasicElement) condition);
    	condition.setIfexpression(o1);
    	condition.setOperation(o2);

    }
    

}
