/**
 */
package ocl_final;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>For All</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ocl_final.ForAll#getSubject <em>Subject</em>}</li>
 * </ul>
 *
 * @see ocl_final.Ocl_finalPackage#getForAll()
 * @model
 * @generated
 */
public interface ForAll extends OpWithoutReturn {
	/**
	 * Returns the value of the '<em><b>Subject</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Subject</em>' attribute.
	 * @see #setSubject(String)
	 * @see ocl_final.Ocl_finalPackage#getForAll_Subject()
	 * @model
	 * @generated
	 */
	String getSubject();

	/**
	 * Sets the value of the '{@link ocl_final.ForAll#getSubject <em>Subject</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Subject</em>' attribute.
	 * @see #getSubject()
	 * @generated
	 */
	void setSubject(String value);

} // ForAll
