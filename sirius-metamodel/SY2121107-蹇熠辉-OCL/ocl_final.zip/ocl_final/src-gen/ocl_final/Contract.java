/**
 */
package ocl_final;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Contract</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ocl_final.Contract#getName <em>Name</em>}</li>
 *   <li>{@link ocl_final.Contract#getPostcondition <em>Postcondition</em>}</li>
 *   <li>{@link ocl_final.Contract#getPrecondition <em>Precondition</em>}</li>
 *   <li>{@link ocl_final.Contract#getService <em>Service</em>}</li>
 * </ul>
 *
 * @see ocl_final.Ocl_finalPackage#getContract()
 * @model
 * @generated
 */
public interface Contract extends BasicElement {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see ocl_final.Ocl_finalPackage#getContract_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link ocl_final.Contract#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Postcondition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Postcondition</em>' reference.
	 * @see #setPostcondition(Postcondition)
	 * @see ocl_final.Ocl_finalPackage#getContract_Postcondition()
	 * @model
	 * @generated
	 */
	Postcondition getPostcondition();

	/**
	 * Sets the value of the '{@link ocl_final.Contract#getPostcondition <em>Postcondition</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Postcondition</em>' reference.
	 * @see #getPostcondition()
	 * @generated
	 */
	void setPostcondition(Postcondition value);

	/**
	 * Returns the value of the '<em><b>Precondition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Precondition</em>' reference.
	 * @see #setPrecondition(Precondition)
	 * @see ocl_final.Ocl_finalPackage#getContract_Precondition()
	 * @model
	 * @generated
	 */
	Precondition getPrecondition();

	/**
	 * Sets the value of the '{@link ocl_final.Contract#getPrecondition <em>Precondition</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Precondition</em>' reference.
	 * @see #getPrecondition()
	 * @generated
	 */
	void setPrecondition(Precondition value);

	/**
	 * Returns the value of the '<em><b>Service</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Service</em>' attribute.
	 * @see #setService(String)
	 * @see ocl_final.Ocl_finalPackage#getContract_Service()
	 * @model
	 * @generated
	 */
	String getService();

	/**
	 * Sets the value of the '{@link ocl_final.Contract#getService <em>Service</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Service</em>' attribute.
	 * @see #getService()
	 * @generated
	 */
	void setService(String value);

} // Contract
