/**
 */
package ocl_final;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Set Attribute</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ocl_final.SetAttribute#getAttrName <em>Attr Name</em>}</li>
 *   <li>{@link ocl_final.SetAttribute#getValue <em>Value</em>}</li>
 * </ul>
 *
 * @see ocl_final.Ocl_finalPackage#getSetAttribute()
 * @model
 * @generated
 */
public interface SetAttribute extends OpWithoutReturn {
	/**
	 * Returns the value of the '<em><b>Attr Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attr Name</em>' attribute.
	 * @see #setAttrName(String)
	 * @see ocl_final.Ocl_finalPackage#getSetAttribute_AttrName()
	 * @model
	 * @generated
	 */
	String getAttrName();

	/**
	 * Sets the value of the '{@link ocl_final.SetAttribute#getAttrName <em>Attr Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Attr Name</em>' attribute.
	 * @see #getAttrName()
	 * @generated
	 */
	void setAttrName(String value);

	/**
	 * Returns the value of the '<em><b>Value</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Value</em>' reference.
	 * @see #setValue(OpWithReturnAttr)
	 * @see ocl_final.Ocl_finalPackage#getSetAttribute_Value()
	 * @model
	 * @generated
	 */
	OpWithReturnAttr getValue();

	/**
	 * Sets the value of the '{@link ocl_final.SetAttribute#getValue <em>Value</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Value</em>' reference.
	 * @see #getValue()
	 * @generated
	 */
	void setValue(OpWithReturnAttr value);

} // SetAttribute
