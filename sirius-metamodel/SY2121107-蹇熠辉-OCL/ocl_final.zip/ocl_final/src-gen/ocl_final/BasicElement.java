/**
 */
package ocl_final;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Basic Element</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ocl_final.Ocl_finalPackage#getBasicElement()
 * @model abstract="true"
 * @generated
 */
public interface BasicElement extends EObject {
} // BasicElement
