/**
 */
package ocl_final.util;

import ocl_final.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see ocl_final.Ocl_finalPackage
 * @generated
 */
public class Ocl_finalAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static Ocl_finalPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Ocl_finalAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = Ocl_finalPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Ocl_finalSwitch<Adapter> modelSwitch = new Ocl_finalSwitch<Adapter>() {
		@Override
		public Adapter caseOCL(OCL object) {
			return createOCLAdapter();
		}

		@Override
		public Adapter caseContract(Contract object) {
			return createContractAdapter();
		}

		@Override
		public Adapter casePrecondition(Precondition object) {
			return createPreconditionAdapter();
		}

		@Override
		public Adapter casePostcondition(Postcondition object) {
			return createPostconditionAdapter();
		}

		@Override
		public Adapter caseOpWithReturnLink(OpWithReturnLink object) {
			return createOpWithReturnLinkAdapter();
		}

		@Override
		public Adapter caseFindObject(FindObject object) {
			return createFindObjectAdapter();
		}

		@Override
		public Adapter caseFindObjects(FindObjects object) {
			return createFindObjectsAdapter();
		}

		@Override
		public Adapter caseCompare(Compare object) {
			return createCompareAdapter();
		}

		@Override
		public Adapter caseCreateObject(CreateObject object) {
			return createCreateObjectAdapter();
		}

		@Override
		public Adapter caseAddObject(AddObject object) {
			return createAddObjectAdapter();
		}

		@Override
		public Adapter caseReleaseObject(ReleaseObject object) {
			return createReleaseObjectAdapter();
		}

		@Override
		public Adapter caseGetAttribute(GetAttribute object) {
			return createGetAttributeAdapter();
		}

		@Override
		public Adapter caseOpWithoutReturn(OpWithoutReturn object) {
			return createOpWithoutReturnAdapter();
		}

		@Override
		public Adapter caseSetAttribute(SetAttribute object) {
			return createSetAttributeAdapter();
		}

		@Override
		public Adapter caseFindLinkedObject(FindLinkedObject object) {
			return createFindLinkedObjectAdapter();
		}

		@Override
		public Adapter caseFindLinkedObjects(FindLinkedObjects object) {
			return createFindLinkedObjectsAdapter();
		}

		@Override
		public Adapter caseAddLinkOneToOne(AddLinkOneToOne object) {
			return createAddLinkOneToOneAdapter();
		}

		@Override
		public Adapter caseOpWithReturnAttr(OpWithReturnAttr object) {
			return createOpWithReturnAttrAdapter();
		}

		@Override
		public Adapter caseOpWithReturnLinks(OpWithReturnLinks object) {
			return createOpWithReturnLinksAdapter();
		}

		@Override
		public Adapter caseAddLinkOneToMany(AddLinkOneToMany object) {
			return createAddLinkOneToManyAdapter();
		}

		@Override
		public Adapter caseRemoveLinkOneToOne(RemoveLinkOneToOne object) {
			return createRemoveLinkOneToOneAdapter();
		}

		@Override
		public Adapter caseRemoveLinkOneToMany(RemoveLinkOneToMany object) {
			return createRemoveLinkOneToManyAdapter();
		}

		@Override
		public Adapter caseLiteral(Literal object) {
			return createLiteralAdapter();
		}

		@Override
		public Adapter caseOpWithReturn(OpWithReturn object) {
			return createOpWithReturnAdapter();
		}

		@Override
		public Adapter caseThirdPartyService(ThirdPartyService object) {
			return createThirdPartyServiceAdapter();
		}

		@Override
		public Adapter caseOCLIsUndefined(OCLIsUndefined object) {
			return createOCLIsUndefinedAdapter();
		}

		@Override
		public Adapter caseNotEmpty(NotEmpty object) {
			return createNotEmptyAdapter();
		}

		@Override
		public Adapter caseSetReturn(SetReturn object) {
			return createSetReturnAdapter();
		}

		@Override
		public Adapter caseOperation(Operation object) {
			return createOperationAdapter();
		}

		@Override
		public Adapter caseIfExpression(IfExpression object) {
			return createIfExpressionAdapter();
		}

		@Override
		public Adapter caseForAll(ForAll object) {
			return createForAllAdapter();
		}

		@Override
		public Adapter caseCondition(Condition object) {
			return createConditionAdapter();
		}

		@Override
		public Adapter caseThen(Then object) {
			return createThenAdapter();
		}

		@Override
		public Adapter caseElse(Else object) {
			return createElseAdapter();
		}

		@Override
		public Adapter caseBasicElement(BasicElement object) {
			return createBasicElementAdapter();
		}

		@Override
		public Adapter caseConjunction(Conjunction object) {
			return createConjunctionAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.OCL <em>OCL</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.OCL
	 * @generated
	 */
	public Adapter createOCLAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.Contract <em>Contract</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.Contract
	 * @generated
	 */
	public Adapter createContractAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.Precondition <em>Precondition</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.Precondition
	 * @generated
	 */
	public Adapter createPreconditionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.Postcondition <em>Postcondition</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.Postcondition
	 * @generated
	 */
	public Adapter createPostconditionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.OpWithReturnLink <em>Op With Return Link</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.OpWithReturnLink
	 * @generated
	 */
	public Adapter createOpWithReturnLinkAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.FindObject <em>Find Object</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.FindObject
	 * @generated
	 */
	public Adapter createFindObjectAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.FindObjects <em>Find Objects</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.FindObjects
	 * @generated
	 */
	public Adapter createFindObjectsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.Compare <em>Compare</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.Compare
	 * @generated
	 */
	public Adapter createCompareAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.CreateObject <em>Create Object</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.CreateObject
	 * @generated
	 */
	public Adapter createCreateObjectAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.AddObject <em>Add Object</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.AddObject
	 * @generated
	 */
	public Adapter createAddObjectAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.ReleaseObject <em>Release Object</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.ReleaseObject
	 * @generated
	 */
	public Adapter createReleaseObjectAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.GetAttribute <em>Get Attribute</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.GetAttribute
	 * @generated
	 */
	public Adapter createGetAttributeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.OpWithoutReturn <em>Op Without Return</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.OpWithoutReturn
	 * @generated
	 */
	public Adapter createOpWithoutReturnAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.SetAttribute <em>Set Attribute</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.SetAttribute
	 * @generated
	 */
	public Adapter createSetAttributeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.FindLinkedObject <em>Find Linked Object</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.FindLinkedObject
	 * @generated
	 */
	public Adapter createFindLinkedObjectAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.FindLinkedObjects <em>Find Linked Objects</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.FindLinkedObjects
	 * @generated
	 */
	public Adapter createFindLinkedObjectsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.AddLinkOneToOne <em>Add Link One To One</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.AddLinkOneToOne
	 * @generated
	 */
	public Adapter createAddLinkOneToOneAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.OpWithReturnAttr <em>Op With Return Attr</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.OpWithReturnAttr
	 * @generated
	 */
	public Adapter createOpWithReturnAttrAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.OpWithReturnLinks <em>Op With Return Links</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.OpWithReturnLinks
	 * @generated
	 */
	public Adapter createOpWithReturnLinksAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.AddLinkOneToMany <em>Add Link One To Many</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.AddLinkOneToMany
	 * @generated
	 */
	public Adapter createAddLinkOneToManyAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.RemoveLinkOneToOne <em>Remove Link One To One</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.RemoveLinkOneToOne
	 * @generated
	 */
	public Adapter createRemoveLinkOneToOneAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.RemoveLinkOneToMany <em>Remove Link One To Many</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.RemoveLinkOneToMany
	 * @generated
	 */
	public Adapter createRemoveLinkOneToManyAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.Literal <em>Literal</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.Literal
	 * @generated
	 */
	public Adapter createLiteralAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.OpWithReturn <em>Op With Return</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.OpWithReturn
	 * @generated
	 */
	public Adapter createOpWithReturnAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.ThirdPartyService <em>Third Party Service</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.ThirdPartyService
	 * @generated
	 */
	public Adapter createThirdPartyServiceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.OCLIsUndefined <em>OCL Is Undefined</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.OCLIsUndefined
	 * @generated
	 */
	public Adapter createOCLIsUndefinedAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.NotEmpty <em>Not Empty</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.NotEmpty
	 * @generated
	 */
	public Adapter createNotEmptyAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.SetReturn <em>Set Return</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.SetReturn
	 * @generated
	 */
	public Adapter createSetReturnAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.Operation <em>Operation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.Operation
	 * @generated
	 */
	public Adapter createOperationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.IfExpression <em>If Expression</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.IfExpression
	 * @generated
	 */
	public Adapter createIfExpressionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.ForAll <em>For All</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.ForAll
	 * @generated
	 */
	public Adapter createForAllAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.Condition <em>Condition</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.Condition
	 * @generated
	 */
	public Adapter createConditionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.Then <em>Then</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.Then
	 * @generated
	 */
	public Adapter createThenAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.Else <em>Else</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.Else
	 * @generated
	 */
	public Adapter createElseAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.BasicElement <em>Basic Element</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.BasicElement
	 * @generated
	 */
	public Adapter createBasicElementAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ocl_final.Conjunction <em>Conjunction</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ocl_final.Conjunction
	 * @generated
	 */
	public Adapter createConjunctionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //Ocl_finalAdapterFactory
