/**
 */
package ocl_final.util;

import ocl_final.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see ocl_final.Ocl_finalPackage
 * @generated
 */
public class Ocl_finalSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static Ocl_finalPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Ocl_finalSwitch() {
		if (modelPackage == null) {
			modelPackage = Ocl_finalPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case Ocl_finalPackage.OCL: {
			OCL ocl = (OCL) theEObject;
			T result = caseOCL(ocl);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.CONTRACT: {
			Contract contract = (Contract) theEObject;
			T result = caseContract(contract);
			if (result == null)
				result = caseBasicElement(contract);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.PRECONDITION: {
			Precondition precondition = (Precondition) theEObject;
			T result = casePrecondition(precondition);
			if (result == null)
				result = caseBasicElement(precondition);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.POSTCONDITION: {
			Postcondition postcondition = (Postcondition) theEObject;
			T result = casePostcondition(postcondition);
			if (result == null)
				result = caseBasicElement(postcondition);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.OP_WITH_RETURN_LINK: {
			OpWithReturnLink opWithReturnLink = (OpWithReturnLink) theEObject;
			T result = caseOpWithReturnLink(opWithReturnLink);
			if (result == null)
				result = caseOpWithReturn(opWithReturnLink);
			if (result == null)
				result = caseOperation(opWithReturnLink);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.FIND_OBJECT: {
			FindObject findObject = (FindObject) theEObject;
			T result = caseFindObject(findObject);
			if (result == null)
				result = caseOpWithReturnLink(findObject);
			if (result == null)
				result = caseOpWithReturn(findObject);
			if (result == null)
				result = caseOperation(findObject);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.FIND_OBJECTS: {
			FindObjects findObjects = (FindObjects) theEObject;
			T result = caseFindObjects(findObjects);
			if (result == null)
				result = caseOpWithReturnLinks(findObjects);
			if (result == null)
				result = caseOpWithReturn(findObjects);
			if (result == null)
				result = caseOperation(findObjects);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.COMPARE: {
			Compare compare = (Compare) theEObject;
			T result = caseCompare(compare);
			if (result == null)
				result = caseOpWithoutReturn(compare);
			if (result == null)
				result = caseOperation(compare);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.CREATE_OBJECT: {
			CreateObject createObject = (CreateObject) theEObject;
			T result = caseCreateObject(createObject);
			if (result == null)
				result = caseOpWithoutReturn(createObject);
			if (result == null)
				result = caseOperation(createObject);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.ADD_OBJECT: {
			AddObject addObject = (AddObject) theEObject;
			T result = caseAddObject(addObject);
			if (result == null)
				result = caseOpWithoutReturn(addObject);
			if (result == null)
				result = caseOperation(addObject);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.RELEASE_OBJECT: {
			ReleaseObject releaseObject = (ReleaseObject) theEObject;
			T result = caseReleaseObject(releaseObject);
			if (result == null)
				result = caseOpWithoutReturn(releaseObject);
			if (result == null)
				result = caseOperation(releaseObject);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.GET_ATTRIBUTE: {
			GetAttribute getAttribute = (GetAttribute) theEObject;
			T result = caseGetAttribute(getAttribute);
			if (result == null)
				result = caseOpWithReturnAttr(getAttribute);
			if (result == null)
				result = caseOpWithReturn(getAttribute);
			if (result == null)
				result = caseOperation(getAttribute);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.OP_WITHOUT_RETURN: {
			OpWithoutReturn opWithoutReturn = (OpWithoutReturn) theEObject;
			T result = caseOpWithoutReturn(opWithoutReturn);
			if (result == null)
				result = caseOperation(opWithoutReturn);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.SET_ATTRIBUTE: {
			SetAttribute setAttribute = (SetAttribute) theEObject;
			T result = caseSetAttribute(setAttribute);
			if (result == null)
				result = caseOpWithoutReturn(setAttribute);
			if (result == null)
				result = caseOperation(setAttribute);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.FIND_LINKED_OBJECT: {
			FindLinkedObject findLinkedObject = (FindLinkedObject) theEObject;
			T result = caseFindLinkedObject(findLinkedObject);
			if (result == null)
				result = caseOpWithReturnLink(findLinkedObject);
			if (result == null)
				result = caseOpWithReturn(findLinkedObject);
			if (result == null)
				result = caseOperation(findLinkedObject);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.FIND_LINKED_OBJECTS: {
			FindLinkedObjects findLinkedObjects = (FindLinkedObjects) theEObject;
			T result = caseFindLinkedObjects(findLinkedObjects);
			if (result == null)
				result = caseOpWithReturnLinks(findLinkedObjects);
			if (result == null)
				result = caseOpWithReturn(findLinkedObjects);
			if (result == null)
				result = caseOperation(findLinkedObjects);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.ADD_LINK_ONE_TO_ONE: {
			AddLinkOneToOne addLinkOneToOne = (AddLinkOneToOne) theEObject;
			T result = caseAddLinkOneToOne(addLinkOneToOne);
			if (result == null)
				result = caseOpWithoutReturn(addLinkOneToOne);
			if (result == null)
				result = caseOperation(addLinkOneToOne);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.OP_WITH_RETURN_ATTR: {
			OpWithReturnAttr opWithReturnAttr = (OpWithReturnAttr) theEObject;
			T result = caseOpWithReturnAttr(opWithReturnAttr);
			if (result == null)
				result = caseOpWithReturn(opWithReturnAttr);
			if (result == null)
				result = caseOperation(opWithReturnAttr);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.OP_WITH_RETURN_LINKS: {
			OpWithReturnLinks opWithReturnLinks = (OpWithReturnLinks) theEObject;
			T result = caseOpWithReturnLinks(opWithReturnLinks);
			if (result == null)
				result = caseOpWithReturn(opWithReturnLinks);
			if (result == null)
				result = caseOperation(opWithReturnLinks);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.ADD_LINK_ONE_TO_MANY: {
			AddLinkOneToMany addLinkOneToMany = (AddLinkOneToMany) theEObject;
			T result = caseAddLinkOneToMany(addLinkOneToMany);
			if (result == null)
				result = caseOpWithoutReturn(addLinkOneToMany);
			if (result == null)
				result = caseOperation(addLinkOneToMany);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.REMOVE_LINK_ONE_TO_ONE: {
			RemoveLinkOneToOne removeLinkOneToOne = (RemoveLinkOneToOne) theEObject;
			T result = caseRemoveLinkOneToOne(removeLinkOneToOne);
			if (result == null)
				result = caseOpWithoutReturn(removeLinkOneToOne);
			if (result == null)
				result = caseOperation(removeLinkOneToOne);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.REMOVE_LINK_ONE_TO_MANY: {
			RemoveLinkOneToMany removeLinkOneToMany = (RemoveLinkOneToMany) theEObject;
			T result = caseRemoveLinkOneToMany(removeLinkOneToMany);
			if (result == null)
				result = caseOpWithoutReturn(removeLinkOneToMany);
			if (result == null)
				result = caseOperation(removeLinkOneToMany);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.LITERAL: {
			Literal literal = (Literal) theEObject;
			T result = caseLiteral(literal);
			if (result == null)
				result = caseOpWithReturnAttr(literal);
			if (result == null)
				result = caseOpWithReturn(literal);
			if (result == null)
				result = caseOperation(literal);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.OP_WITH_RETURN: {
			OpWithReturn opWithReturn = (OpWithReturn) theEObject;
			T result = caseOpWithReturn(opWithReturn);
			if (result == null)
				result = caseOperation(opWithReturn);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.THIRD_PARTY_SERVICE: {
			ThirdPartyService thirdPartyService = (ThirdPartyService) theEObject;
			T result = caseThirdPartyService(thirdPartyService);
			if (result == null)
				result = caseOpWithReturn(thirdPartyService);
			if (result == null)
				result = caseOperation(thirdPartyService);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.OCL_IS_UNDEFINED: {
			OCLIsUndefined oclIsUndefined = (OCLIsUndefined) theEObject;
			T result = caseOCLIsUndefined(oclIsUndefined);
			if (result == null)
				result = caseOpWithReturnAttr(oclIsUndefined);
			if (result == null)
				result = caseOpWithReturn(oclIsUndefined);
			if (result == null)
				result = caseOperation(oclIsUndefined);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.NOT_EMPTY: {
			NotEmpty notEmpty = (NotEmpty) theEObject;
			T result = caseNotEmpty(notEmpty);
			if (result == null)
				result = caseOpWithReturnAttr(notEmpty);
			if (result == null)
				result = caseOpWithReturn(notEmpty);
			if (result == null)
				result = caseOperation(notEmpty);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.SET_RETURN: {
			SetReturn setReturn = (SetReturn) theEObject;
			T result = caseSetReturn(setReturn);
			if (result == null)
				result = caseOpWithoutReturn(setReturn);
			if (result == null)
				result = caseOperation(setReturn);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.OPERATION: {
			Operation operation = (Operation) theEObject;
			T result = caseOperation(operation);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.IF_EXPRESSION: {
			IfExpression ifExpression = (IfExpression) theEObject;
			T result = caseIfExpression(ifExpression);
			if (result == null)
				result = caseOperation(ifExpression);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.FOR_ALL: {
			ForAll forAll = (ForAll) theEObject;
			T result = caseForAll(forAll);
			if (result == null)
				result = caseOpWithoutReturn(forAll);
			if (result == null)
				result = caseOperation(forAll);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.CONDITION: {
			Condition condition = (Condition) theEObject;
			T result = caseCondition(condition);
			if (result == null)
				result = caseBasicElement(condition);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.THEN: {
			Then then = (Then) theEObject;
			T result = caseThen(then);
			if (result == null)
				result = caseBasicElement(then);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.ELSE: {
			Else else_ = (Else) theEObject;
			T result = caseElse(else_);
			if (result == null)
				result = caseBasicElement(else_);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.BASIC_ELEMENT: {
			BasicElement basicElement = (BasicElement) theEObject;
			T result = caseBasicElement(basicElement);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ocl_finalPackage.CONJUNCTION: {
			Conjunction conjunction = (Conjunction) theEObject;
			T result = caseConjunction(conjunction);
			if (result == null)
				result = caseBasicElement(conjunction);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>OCL</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>OCL</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOCL(OCL object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Contract</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Contract</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseContract(Contract object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Precondition</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Precondition</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePrecondition(Precondition object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Postcondition</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Postcondition</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePostcondition(Postcondition object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Op With Return Link</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Op With Return Link</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOpWithReturnLink(OpWithReturnLink object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Find Object</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Find Object</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseFindObject(FindObject object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Find Objects</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Find Objects</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseFindObjects(FindObjects object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Compare</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Compare</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCompare(Compare object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Create Object</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Create Object</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCreateObject(CreateObject object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Add Object</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Add Object</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAddObject(AddObject object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Release Object</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Release Object</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseReleaseObject(ReleaseObject object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Get Attribute</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Get Attribute</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseGetAttribute(GetAttribute object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Op Without Return</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Op Without Return</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOpWithoutReturn(OpWithoutReturn object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Set Attribute</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Set Attribute</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSetAttribute(SetAttribute object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Find Linked Object</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Find Linked Object</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseFindLinkedObject(FindLinkedObject object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Find Linked Objects</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Find Linked Objects</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseFindLinkedObjects(FindLinkedObjects object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Add Link One To One</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Add Link One To One</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAddLinkOneToOne(AddLinkOneToOne object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Op With Return Attr</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Op With Return Attr</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOpWithReturnAttr(OpWithReturnAttr object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Op With Return Links</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Op With Return Links</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOpWithReturnLinks(OpWithReturnLinks object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Add Link One To Many</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Add Link One To Many</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAddLinkOneToMany(AddLinkOneToMany object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Remove Link One To One</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Remove Link One To One</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRemoveLinkOneToOne(RemoveLinkOneToOne object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Remove Link One To Many</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Remove Link One To Many</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRemoveLinkOneToMany(RemoveLinkOneToMany object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Literal</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Literal</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseLiteral(Literal object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Op With Return</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Op With Return</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOpWithReturn(OpWithReturn object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Third Party Service</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Third Party Service</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseThirdPartyService(ThirdPartyService object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>OCL Is Undefined</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>OCL Is Undefined</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOCLIsUndefined(OCLIsUndefined object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Not Empty</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Not Empty</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseNotEmpty(NotEmpty object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Set Return</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Set Return</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSetReturn(SetReturn object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Operation</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Operation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOperation(Operation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>If Expression</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>If Expression</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseIfExpression(IfExpression object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>For All</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>For All</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseForAll(ForAll object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Condition</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Condition</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCondition(Condition object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Then</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Then</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseThen(Then object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Else</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Else</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseElse(Else object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Basic Element</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Basic Element</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBasicElement(BasicElement object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Conjunction</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Conjunction</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseConjunction(Conjunction object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //Ocl_finalSwitch
