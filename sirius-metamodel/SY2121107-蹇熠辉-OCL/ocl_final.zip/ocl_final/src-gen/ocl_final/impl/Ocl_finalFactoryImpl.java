/**
 */
package ocl_final.impl;

import ocl_final.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class Ocl_finalFactoryImpl extends EFactoryImpl implements Ocl_finalFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Ocl_finalFactory init() {
		try {
			Ocl_finalFactory theOcl_finalFactory = (Ocl_finalFactory) EPackage.Registry.INSTANCE
					.getEFactory(Ocl_finalPackage.eNS_URI);
			if (theOcl_finalFactory != null) {
				return theOcl_finalFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new Ocl_finalFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Ocl_finalFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case Ocl_finalPackage.OCL:
			return createOCL();
		case Ocl_finalPackage.CONTRACT:
			return createContract();
		case Ocl_finalPackage.PRECONDITION:
			return createPrecondition();
		case Ocl_finalPackage.POSTCONDITION:
			return createPostcondition();
		case Ocl_finalPackage.FIND_OBJECT:
			return createFindObject();
		case Ocl_finalPackage.FIND_OBJECTS:
			return createFindObjects();
		case Ocl_finalPackage.COMPARE:
			return createCompare();
		case Ocl_finalPackage.CREATE_OBJECT:
			return createCreateObject();
		case Ocl_finalPackage.ADD_OBJECT:
			return createAddObject();
		case Ocl_finalPackage.RELEASE_OBJECT:
			return createReleaseObject();
		case Ocl_finalPackage.GET_ATTRIBUTE:
			return createGetAttribute();
		case Ocl_finalPackage.SET_ATTRIBUTE:
			return createSetAttribute();
		case Ocl_finalPackage.FIND_LINKED_OBJECT:
			return createFindLinkedObject();
		case Ocl_finalPackage.FIND_LINKED_OBJECTS:
			return createFindLinkedObjects();
		case Ocl_finalPackage.ADD_LINK_ONE_TO_ONE:
			return createAddLinkOneToOne();
		case Ocl_finalPackage.ADD_LINK_ONE_TO_MANY:
			return createAddLinkOneToMany();
		case Ocl_finalPackage.REMOVE_LINK_ONE_TO_ONE:
			return createRemoveLinkOneToOne();
		case Ocl_finalPackage.REMOVE_LINK_ONE_TO_MANY:
			return createRemoveLinkOneToMany();
		case Ocl_finalPackage.LITERAL:
			return createLiteral();
		case Ocl_finalPackage.THIRD_PARTY_SERVICE:
			return createThirdPartyService();
		case Ocl_finalPackage.OCL_IS_UNDEFINED:
			return createOCLIsUndefined();
		case Ocl_finalPackage.NOT_EMPTY:
			return createNotEmpty();
		case Ocl_finalPackage.SET_RETURN:
			return createSetReturn();
		case Ocl_finalPackage.IF_EXPRESSION:
			return createIfExpression();
		case Ocl_finalPackage.FOR_ALL:
			return createForAll();
		case Ocl_finalPackage.CONDITION:
			return createCondition();
		case Ocl_finalPackage.THEN:
			return createThen();
		case Ocl_finalPackage.ELSE:
			return createElse();
		case Ocl_finalPackage.CONJUNCTION:
			return createConjunction();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
		case Ocl_finalPackage.COMPARE_TYPE:
			return createCompareTypeFromString(eDataType, initialValue);
		case Ocl_finalPackage.LOGIC_OPERATION:
			return createLogicOperationFromString(eDataType, initialValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
		case Ocl_finalPackage.COMPARE_TYPE:
			return convertCompareTypeToString(eDataType, instanceValue);
		case Ocl_finalPackage.LOGIC_OPERATION:
			return convertLogicOperationToString(eDataType, instanceValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OCL createOCL() {
		OCLImpl ocl = new OCLImpl();
		return ocl;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Contract createContract() {
		ContractImpl contract = new ContractImpl();
		return contract;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Precondition createPrecondition() {
		PreconditionImpl precondition = new PreconditionImpl();
		return precondition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Postcondition createPostcondition() {
		PostconditionImpl postcondition = new PostconditionImpl();
		return postcondition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FindObject createFindObject() {
		FindObjectImpl findObject = new FindObjectImpl();
		return findObject;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FindObjects createFindObjects() {
		FindObjectsImpl findObjects = new FindObjectsImpl();
		return findObjects;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Compare createCompare() {
		CompareImpl compare = new CompareImpl();
		return compare;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CreateObject createCreateObject() {
		CreateObjectImpl createObject = new CreateObjectImpl();
		return createObject;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AddObject createAddObject() {
		AddObjectImpl addObject = new AddObjectImpl();
		return addObject;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ReleaseObject createReleaseObject() {
		ReleaseObjectImpl releaseObject = new ReleaseObjectImpl();
		return releaseObject;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GetAttribute createGetAttribute() {
		GetAttributeImpl getAttribute = new GetAttributeImpl();
		return getAttribute;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SetAttribute createSetAttribute() {
		SetAttributeImpl setAttribute = new SetAttributeImpl();
		return setAttribute;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FindLinkedObject createFindLinkedObject() {
		FindLinkedObjectImpl findLinkedObject = new FindLinkedObjectImpl();
		return findLinkedObject;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FindLinkedObjects createFindLinkedObjects() {
		FindLinkedObjectsImpl findLinkedObjects = new FindLinkedObjectsImpl();
		return findLinkedObjects;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AddLinkOneToOne createAddLinkOneToOne() {
		AddLinkOneToOneImpl addLinkOneToOne = new AddLinkOneToOneImpl();
		return addLinkOneToOne;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AddLinkOneToMany createAddLinkOneToMany() {
		AddLinkOneToManyImpl addLinkOneToMany = new AddLinkOneToManyImpl();
		return addLinkOneToMany;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RemoveLinkOneToOne createRemoveLinkOneToOne() {
		RemoveLinkOneToOneImpl removeLinkOneToOne = new RemoveLinkOneToOneImpl();
		return removeLinkOneToOne;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RemoveLinkOneToMany createRemoveLinkOneToMany() {
		RemoveLinkOneToManyImpl removeLinkOneToMany = new RemoveLinkOneToManyImpl();
		return removeLinkOneToMany;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Literal createLiteral() {
		LiteralImpl literal = new LiteralImpl();
		return literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ThirdPartyService createThirdPartyService() {
		ThirdPartyServiceImpl thirdPartyService = new ThirdPartyServiceImpl();
		return thirdPartyService;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OCLIsUndefined createOCLIsUndefined() {
		OCLIsUndefinedImpl oclIsUndefined = new OCLIsUndefinedImpl();
		return oclIsUndefined;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotEmpty createNotEmpty() {
		NotEmptyImpl notEmpty = new NotEmptyImpl();
		return notEmpty;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SetReturn createSetReturn() {
		SetReturnImpl setReturn = new SetReturnImpl();
		return setReturn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IfExpression createIfExpression() {
		IfExpressionImpl ifExpression = new IfExpressionImpl();
		return ifExpression;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ForAll createForAll() {
		ForAllImpl forAll = new ForAllImpl();
		return forAll;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Condition createCondition() {
		ConditionImpl condition = new ConditionImpl();
		return condition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Then createThen() {
		ThenImpl then = new ThenImpl();
		return then;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Else createElse() {
		ElseImpl else_ = new ElseImpl();
		return else_;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Conjunction createConjunction() {
		ConjunctionImpl conjunction = new ConjunctionImpl();
		return conjunction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CompareType createCompareTypeFromString(EDataType eDataType, String initialValue) {
		CompareType result = CompareType.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertCompareTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LogicOperation createLogicOperationFromString(EDataType eDataType, String initialValue) {
		LogicOperation result = LogicOperation.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertLogicOperationToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Ocl_finalPackage getOcl_finalPackage() {
		return (Ocl_finalPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static Ocl_finalPackage getPackage() {
		return Ocl_finalPackage.eINSTANCE;
	}

} //Ocl_finalFactoryImpl
