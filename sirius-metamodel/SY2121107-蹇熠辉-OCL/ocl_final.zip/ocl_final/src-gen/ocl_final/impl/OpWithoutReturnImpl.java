/**
 */
package ocl_final.impl;

import ocl_final.Ocl_finalPackage;
import ocl_final.OpWithoutReturn;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Op Without Return</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class OpWithoutReturnImpl extends OperationImpl implements OpWithoutReturn {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OpWithoutReturnImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ocl_finalPackage.Literals.OP_WITHOUT_RETURN;
	}

} //OpWithoutReturnImpl
