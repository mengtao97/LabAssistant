/**
 */
package ocl_final.impl;

import ocl_final.BasicElement;
import ocl_final.Ocl_finalPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Basic Element</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class BasicElementImpl extends MinimalEObjectImpl.Container implements BasicElement {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BasicElementImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ocl_finalPackage.Literals.BASIC_ELEMENT;
	}

} //BasicElementImpl
