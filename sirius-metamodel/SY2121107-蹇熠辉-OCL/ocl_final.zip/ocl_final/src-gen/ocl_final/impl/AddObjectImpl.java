/**
 */
package ocl_final.impl;

import ocl_final.AddObject;
import ocl_final.Ocl_finalPackage;
import ocl_final.OpWithReturnLink;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Add Object</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ocl_final.impl.AddObjectImpl#getObName <em>Ob Name</em>}</li>
 *   <li>{@link ocl_final.impl.AddObjectImpl#getObj <em>Obj</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AddObjectImpl extends OpWithoutReturnImpl implements AddObject {
	/**
	 * The default value of the '{@link #getObName() <em>Ob Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getObName()
	 * @generated
	 * @ordered
	 */
	protected static final String OB_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getObName() <em>Ob Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getObName()
	 * @generated
	 * @ordered
	 */
	protected String obName = OB_NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getObj() <em>Obj</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getObj()
	 * @generated
	 * @ordered
	 */
	protected OpWithReturnLink obj;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AddObjectImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ocl_finalPackage.Literals.ADD_OBJECT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getObName() {
		return obName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setObName(String newObName) {
		String oldObName = obName;
		obName = newObName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ocl_finalPackage.ADD_OBJECT__OB_NAME, oldObName,
					obName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OpWithReturnLink getObj() {
		if (obj != null && obj.eIsProxy()) {
			InternalEObject oldObj = (InternalEObject) obj;
			obj = (OpWithReturnLink) eResolveProxy(oldObj);
			if (obj != oldObj) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Ocl_finalPackage.ADD_OBJECT__OBJ, oldObj,
							obj));
			}
		}
		return obj;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OpWithReturnLink basicGetObj() {
		return obj;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setObj(OpWithReturnLink newObj) {
		OpWithReturnLink oldObj = obj;
		obj = newObj;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ocl_finalPackage.ADD_OBJECT__OBJ, oldObj, obj));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Ocl_finalPackage.ADD_OBJECT__OB_NAME:
			return getObName();
		case Ocl_finalPackage.ADD_OBJECT__OBJ:
			if (resolve)
				return getObj();
			return basicGetObj();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Ocl_finalPackage.ADD_OBJECT__OB_NAME:
			setObName((String) newValue);
			return;
		case Ocl_finalPackage.ADD_OBJECT__OBJ:
			setObj((OpWithReturnLink) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Ocl_finalPackage.ADD_OBJECT__OB_NAME:
			setObName(OB_NAME_EDEFAULT);
			return;
		case Ocl_finalPackage.ADD_OBJECT__OBJ:
			setObj((OpWithReturnLink) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Ocl_finalPackage.ADD_OBJECT__OB_NAME:
			return OB_NAME_EDEFAULT == null ? obName != null : !OB_NAME_EDEFAULT.equals(obName);
		case Ocl_finalPackage.ADD_OBJECT__OBJ:
			return obj != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (obName: ");
		result.append(obName);
		result.append(')');
		return result.toString();
	}

} //AddObjectImpl
