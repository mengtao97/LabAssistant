/**
 */
package ocl_final.impl;

import ocl_final.AddLinkOneToMany;
import ocl_final.AddLinkOneToOne;
import ocl_final.AddObject;
import ocl_final.BasicElement;
import ocl_final.Compare;
import ocl_final.CompareType;
import ocl_final.Condition;
import ocl_final.Conjunction;
import ocl_final.Contract;
import ocl_final.CreateObject;
import ocl_final.Else;
import ocl_final.FindLinkedObject;
import ocl_final.FindLinkedObjects;
import ocl_final.FindObject;
import ocl_final.FindObjects;
import ocl_final.ForAll;
import ocl_final.GetAttribute;
import ocl_final.IfExpression;
import ocl_final.Literal;
import ocl_final.LogicOperation;
import ocl_final.NotEmpty;
import ocl_final.OCLIsUndefined;
import ocl_final.Ocl_finalFactory;
import ocl_final.Ocl_finalPackage;
import ocl_final.OpWithReturn;
import ocl_final.OpWithReturnAttr;
import ocl_final.OpWithReturnLink;
import ocl_final.OpWithReturnLinks;
import ocl_final.OpWithoutReturn;
import ocl_final.Operation;
import ocl_final.Postcondition;
import ocl_final.Precondition;
import ocl_final.ReleaseObject;
import ocl_final.RemoveLinkOneToMany;
import ocl_final.RemoveLinkOneToOne;
import ocl_final.SetAttribute;
import ocl_final.SetReturn;
import ocl_final.Then;
import ocl_final.ThirdPartyService;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class Ocl_finalPackageImpl extends EPackageImpl implements Ocl_finalPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass oclEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass contractEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass preconditionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass postconditionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass opWithReturnLinkEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass findObjectEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass findObjectsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass compareEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass createObjectEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass addObjectEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass releaseObjectEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass getAttributeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass opWithoutReturnEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass setAttributeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass findLinkedObjectEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass findLinkedObjectsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass addLinkOneToOneEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass opWithReturnAttrEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass opWithReturnLinksEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass addLinkOneToManyEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass removeLinkOneToOneEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass removeLinkOneToManyEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass literalEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass opWithReturnEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass thirdPartyServiceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass oclIsUndefinedEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass notEmptyEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass setReturnEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass operationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass ifExpressionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass forAllEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass conditionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass thenEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass elseEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass basicElementEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass conjunctionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum compareTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum logicOperationEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see ocl_final.Ocl_finalPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private Ocl_finalPackageImpl() {
		super(eNS_URI, Ocl_finalFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link Ocl_finalPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static Ocl_finalPackage init() {
		if (isInited)
			return (Ocl_finalPackage) EPackage.Registry.INSTANCE.getEPackage(Ocl_finalPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredOcl_finalPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		Ocl_finalPackageImpl theOcl_finalPackage = registeredOcl_finalPackage instanceof Ocl_finalPackageImpl
				? (Ocl_finalPackageImpl) registeredOcl_finalPackage
				: new Ocl_finalPackageImpl();

		isInited = true;

		// Create package meta-data objects
		theOcl_finalPackage.createPackageContents();

		// Initialize created meta-data
		theOcl_finalPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theOcl_finalPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(Ocl_finalPackage.eNS_URI, theOcl_finalPackage);
		return theOcl_finalPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOCL() {
		return oclEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOCL_Basicelement() {
		return (EReference) oclEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOCL_Operation() {
		return (EReference) oclEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getContract() {
		return contractEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getContract_Name() {
		return (EAttribute) contractEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getContract_Postcondition() {
		return (EReference) contractEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getContract_Precondition() {
		return (EReference) contractEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getContract_Service() {
		return (EAttribute) contractEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPrecondition() {
		return preconditionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPrecondition_Operation() {
		return (EReference) preconditionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPostcondition() {
		return postconditionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPostcondition_Operation() {
		return (EReference) postconditionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOpWithReturnLink() {
		return opWithReturnLinkEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFindObject() {
		return findObjectEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFindObject_Condition() {
		return (EReference) findObjectEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFindObjects() {
		return findObjectsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFindObjects_Condition() {
		return (EReference) findObjectsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCompare() {
		return compareEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCompare_Op() {
		return (EAttribute) compareEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCompare_Subject() {
		return (EReference) compareEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCompare_Object() {
		return (EReference) compareEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCreateObject() {
		return createObjectEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCreateObject_ObName() {
		return (EAttribute) createObjectEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAddObject() {
		return addObjectEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAddObject_ObName() {
		return (EAttribute) addObjectEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAddObject_Obj() {
		return (EReference) addObjectEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getReleaseObject() {
		return releaseObjectEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getReleaseObject_ObName() {
		return (EAttribute) releaseObjectEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getReleaseObject_Obj() {
		return (EReference) releaseObjectEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getGetAttribute() {
		return getAttributeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGetAttribute_AttrName() {
		return (EAttribute) getAttributeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOpWithoutReturn() {
		return opWithoutReturnEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSetAttribute() {
		return setAttributeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSetAttribute_AttrName() {
		return (EAttribute) setAttributeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSetAttribute_Value() {
		return (EReference) setAttributeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFindLinkedObject() {
		return findLinkedObjectEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFindLinkedObject_ObName() {
		return (EAttribute) findLinkedObjectEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFindLinkedObject_Condition() {
		return (EReference) findLinkedObjectEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFindLinkedObjects() {
		return findLinkedObjectsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFindLinkedObjects_ObName() {
		return (EAttribute) findLinkedObjectsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFindLinkedObjects_Condition() {
		return (EReference) findLinkedObjectsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAddLinkOneToOne() {
		return addLinkOneToOneEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAddLinkOneToOne_LinkName() {
		return (EAttribute) addLinkOneToOneEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAddLinkOneToOne_Ref() {
		return (EReference) addLinkOneToOneEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOpWithReturnAttr() {
		return opWithReturnAttrEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOpWithReturnLinks() {
		return opWithReturnLinksEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAddLinkOneToMany() {
		return addLinkOneToManyEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAddLinkOneToMany_LinkName() {
		return (EAttribute) addLinkOneToManyEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAddLinkOneToMany_Ref() {
		return (EReference) addLinkOneToManyEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRemoveLinkOneToOne() {
		return removeLinkOneToOneEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRemoveLinkOneToOne_LinkName() {
		return (EAttribute) removeLinkOneToOneEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRemoveLinkOneToOne_Ref() {
		return (EReference) removeLinkOneToOneEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRemoveLinkOneToMany() {
		return removeLinkOneToManyEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRemoveLinkOneToMany_LinkName() {
		return (EAttribute) removeLinkOneToManyEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRemoveLinkOneToMany_Ref() {
		return (EReference) removeLinkOneToManyEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getLiteral() {
		return literalEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getLiteral_Value() {
		return (EAttribute) literalEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOpWithReturn() {
		return opWithReturnEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getThirdPartyService() {
		return thirdPartyServiceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getThirdPartyService_ServiceName() {
		return (EAttribute) thirdPartyServiceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getThirdPartyService_Param() {
		return (EReference) thirdPartyServiceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOCLIsUndefined() {
		return oclIsUndefinedEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOCLIsUndefined_Subject() {
		return (EAttribute) oclIsUndefinedEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getNotEmpty() {
		return notEmptyEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getNotEmpty_Subject() {
		return (EAttribute) notEmptyEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSetReturn() {
		return setReturnEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSetReturn_Return() {
		return (EAttribute) setReturnEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOperation() {
		return operationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOperation_Prev_conj() {
		return (EReference) operationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOperation_Next_conj() {
		return (EReference) operationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getIfExpression() {
		return ifExpressionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getForAll() {
		return forAllEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getForAll_Subject() {
		return (EAttribute) forAllEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCondition() {
		return conditionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCondition_Operation() {
		return (EReference) conditionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCondition_Ifexpression() {
		return (EReference) conditionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getThen() {
		return thenEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getThen_Operation() {
		return (EReference) thenEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getThen_Ifexpression() {
		return (EReference) thenEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getElse() {
		return elseEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getElse_Operation() {
		return (EReference) elseEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getElse_Ifexpression() {
		return (EReference) elseEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBasicElement() {
		return basicElementEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getConjunction() {
		return conjunctionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getConjunction_Op() {
		return (EAttribute) conjunctionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getConjunction_Prev() {
		return (EReference) conjunctionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getConjunction_Next() {
		return (EReference) conjunctionEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getCompareType() {
		return compareTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getLogicOperation() {
		return logicOperationEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Ocl_finalFactory getOcl_finalFactory() {
		return (Ocl_finalFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		oclEClass = createEClass(OCL);
		createEReference(oclEClass, OCL__BASICELEMENT);
		createEReference(oclEClass, OCL__OPERATION);

		contractEClass = createEClass(CONTRACT);
		createEAttribute(contractEClass, CONTRACT__NAME);
		createEReference(contractEClass, CONTRACT__POSTCONDITION);
		createEReference(contractEClass, CONTRACT__PRECONDITION);
		createEAttribute(contractEClass, CONTRACT__SERVICE);

		preconditionEClass = createEClass(PRECONDITION);
		createEReference(preconditionEClass, PRECONDITION__OPERATION);

		postconditionEClass = createEClass(POSTCONDITION);
		createEReference(postconditionEClass, POSTCONDITION__OPERATION);

		opWithReturnLinkEClass = createEClass(OP_WITH_RETURN_LINK);

		findObjectEClass = createEClass(FIND_OBJECT);
		createEReference(findObjectEClass, FIND_OBJECT__CONDITION);

		findObjectsEClass = createEClass(FIND_OBJECTS);
		createEReference(findObjectsEClass, FIND_OBJECTS__CONDITION);

		compareEClass = createEClass(COMPARE);
		createEAttribute(compareEClass, COMPARE__OP);
		createEReference(compareEClass, COMPARE__SUBJECT);
		createEReference(compareEClass, COMPARE__OBJECT);

		createObjectEClass = createEClass(CREATE_OBJECT);
		createEAttribute(createObjectEClass, CREATE_OBJECT__OB_NAME);

		addObjectEClass = createEClass(ADD_OBJECT);
		createEAttribute(addObjectEClass, ADD_OBJECT__OB_NAME);
		createEReference(addObjectEClass, ADD_OBJECT__OBJ);

		releaseObjectEClass = createEClass(RELEASE_OBJECT);
		createEAttribute(releaseObjectEClass, RELEASE_OBJECT__OB_NAME);
		createEReference(releaseObjectEClass, RELEASE_OBJECT__OBJ);

		getAttributeEClass = createEClass(GET_ATTRIBUTE);
		createEAttribute(getAttributeEClass, GET_ATTRIBUTE__ATTR_NAME);

		opWithoutReturnEClass = createEClass(OP_WITHOUT_RETURN);

		setAttributeEClass = createEClass(SET_ATTRIBUTE);
		createEAttribute(setAttributeEClass, SET_ATTRIBUTE__ATTR_NAME);
		createEReference(setAttributeEClass, SET_ATTRIBUTE__VALUE);

		findLinkedObjectEClass = createEClass(FIND_LINKED_OBJECT);
		createEAttribute(findLinkedObjectEClass, FIND_LINKED_OBJECT__OB_NAME);
		createEReference(findLinkedObjectEClass, FIND_LINKED_OBJECT__CONDITION);

		findLinkedObjectsEClass = createEClass(FIND_LINKED_OBJECTS);
		createEAttribute(findLinkedObjectsEClass, FIND_LINKED_OBJECTS__OB_NAME);
		createEReference(findLinkedObjectsEClass, FIND_LINKED_OBJECTS__CONDITION);

		addLinkOneToOneEClass = createEClass(ADD_LINK_ONE_TO_ONE);
		createEAttribute(addLinkOneToOneEClass, ADD_LINK_ONE_TO_ONE__LINK_NAME);
		createEReference(addLinkOneToOneEClass, ADD_LINK_ONE_TO_ONE__REF);

		opWithReturnAttrEClass = createEClass(OP_WITH_RETURN_ATTR);

		opWithReturnLinksEClass = createEClass(OP_WITH_RETURN_LINKS);

		addLinkOneToManyEClass = createEClass(ADD_LINK_ONE_TO_MANY);
		createEAttribute(addLinkOneToManyEClass, ADD_LINK_ONE_TO_MANY__LINK_NAME);
		createEReference(addLinkOneToManyEClass, ADD_LINK_ONE_TO_MANY__REF);

		removeLinkOneToOneEClass = createEClass(REMOVE_LINK_ONE_TO_ONE);
		createEAttribute(removeLinkOneToOneEClass, REMOVE_LINK_ONE_TO_ONE__LINK_NAME);
		createEReference(removeLinkOneToOneEClass, REMOVE_LINK_ONE_TO_ONE__REF);

		removeLinkOneToManyEClass = createEClass(REMOVE_LINK_ONE_TO_MANY);
		createEAttribute(removeLinkOneToManyEClass, REMOVE_LINK_ONE_TO_MANY__LINK_NAME);
		createEReference(removeLinkOneToManyEClass, REMOVE_LINK_ONE_TO_MANY__REF);

		literalEClass = createEClass(LITERAL);
		createEAttribute(literalEClass, LITERAL__VALUE);

		opWithReturnEClass = createEClass(OP_WITH_RETURN);

		thirdPartyServiceEClass = createEClass(THIRD_PARTY_SERVICE);
		createEAttribute(thirdPartyServiceEClass, THIRD_PARTY_SERVICE__SERVICE_NAME);
		createEReference(thirdPartyServiceEClass, THIRD_PARTY_SERVICE__PARAM);

		oclIsUndefinedEClass = createEClass(OCL_IS_UNDEFINED);
		createEAttribute(oclIsUndefinedEClass, OCL_IS_UNDEFINED__SUBJECT);

		notEmptyEClass = createEClass(NOT_EMPTY);
		createEAttribute(notEmptyEClass, NOT_EMPTY__SUBJECT);

		setReturnEClass = createEClass(SET_RETURN);
		createEAttribute(setReturnEClass, SET_RETURN__RETURN);

		operationEClass = createEClass(OPERATION);
		createEReference(operationEClass, OPERATION__PREV_CONJ);
		createEReference(operationEClass, OPERATION__NEXT_CONJ);

		ifExpressionEClass = createEClass(IF_EXPRESSION);

		forAllEClass = createEClass(FOR_ALL);
		createEAttribute(forAllEClass, FOR_ALL__SUBJECT);

		conditionEClass = createEClass(CONDITION);
		createEReference(conditionEClass, CONDITION__OPERATION);
		createEReference(conditionEClass, CONDITION__IFEXPRESSION);

		thenEClass = createEClass(THEN);
		createEReference(thenEClass, THEN__OPERATION);
		createEReference(thenEClass, THEN__IFEXPRESSION);

		elseEClass = createEClass(ELSE);
		createEReference(elseEClass, ELSE__OPERATION);
		createEReference(elseEClass, ELSE__IFEXPRESSION);

		basicElementEClass = createEClass(BASIC_ELEMENT);

		conjunctionEClass = createEClass(CONJUNCTION);
		createEAttribute(conjunctionEClass, CONJUNCTION__OP);
		createEReference(conjunctionEClass, CONJUNCTION__PREV);
		createEReference(conjunctionEClass, CONJUNCTION__NEXT);

		// Create enums
		compareTypeEEnum = createEEnum(COMPARE_TYPE);
		logicOperationEEnum = createEEnum(LOGIC_OPERATION);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		contractEClass.getESuperTypes().add(this.getBasicElement());
		preconditionEClass.getESuperTypes().add(this.getBasicElement());
		postconditionEClass.getESuperTypes().add(this.getBasicElement());
		opWithReturnLinkEClass.getESuperTypes().add(this.getOpWithReturn());
		findObjectEClass.getESuperTypes().add(this.getOpWithReturnLink());
		findObjectsEClass.getESuperTypes().add(this.getOpWithReturnLinks());
		compareEClass.getESuperTypes().add(this.getOpWithoutReturn());
		createObjectEClass.getESuperTypes().add(this.getOpWithoutReturn());
		addObjectEClass.getESuperTypes().add(this.getOpWithoutReturn());
		releaseObjectEClass.getESuperTypes().add(this.getOpWithoutReturn());
		getAttributeEClass.getESuperTypes().add(this.getOpWithReturnAttr());
		opWithoutReturnEClass.getESuperTypes().add(this.getOperation());
		setAttributeEClass.getESuperTypes().add(this.getOpWithoutReturn());
		findLinkedObjectEClass.getESuperTypes().add(this.getOpWithReturnLink());
		findLinkedObjectsEClass.getESuperTypes().add(this.getOpWithReturnLinks());
		addLinkOneToOneEClass.getESuperTypes().add(this.getOpWithoutReturn());
		opWithReturnAttrEClass.getESuperTypes().add(this.getOpWithReturn());
		opWithReturnLinksEClass.getESuperTypes().add(this.getOpWithReturn());
		addLinkOneToManyEClass.getESuperTypes().add(this.getOpWithoutReturn());
		removeLinkOneToOneEClass.getESuperTypes().add(this.getOpWithoutReturn());
		removeLinkOneToManyEClass.getESuperTypes().add(this.getOpWithoutReturn());
		literalEClass.getESuperTypes().add(this.getOpWithReturnAttr());
		opWithReturnEClass.getESuperTypes().add(this.getOperation());
		thirdPartyServiceEClass.getESuperTypes().add(this.getOpWithReturn());
		oclIsUndefinedEClass.getESuperTypes().add(this.getOpWithReturnAttr());
		notEmptyEClass.getESuperTypes().add(this.getOpWithReturnAttr());
		setReturnEClass.getESuperTypes().add(this.getOpWithoutReturn());
		ifExpressionEClass.getESuperTypes().add(this.getOperation());
		forAllEClass.getESuperTypes().add(this.getOpWithoutReturn());
		conditionEClass.getESuperTypes().add(this.getBasicElement());
		thenEClass.getESuperTypes().add(this.getBasicElement());
		elseEClass.getESuperTypes().add(this.getBasicElement());
		conjunctionEClass.getESuperTypes().add(this.getBasicElement());

		// Initialize classes, features, and operations; add parameters
		initEClass(oclEClass, ocl_final.OCL.class, "OCL", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getOCL_Basicelement(), this.getBasicElement(), null, "basicelement", null, 0, -1,
				ocl_final.OCL.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getOCL_Operation(), this.getOperation(), null, "operation", null, 0, -1, ocl_final.OCL.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(contractEClass, Contract.class, "Contract", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getContract_Name(), ecorePackage.getEString(), "name", null, 0, 1, Contract.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getContract_Postcondition(), this.getPostcondition(), null, "postcondition", null, 0, 1,
				Contract.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getContract_Precondition(), this.getPrecondition(), null, "precondition", null, 0, 1,
				Contract.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getContract_Service(), ecorePackage.getEString(), "service", null, 0, 1, Contract.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(preconditionEClass, Precondition.class, "Precondition", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPrecondition_Operation(), this.getOperation(), null, "operation", null, 0, 1,
				Precondition.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(postconditionEClass, Postcondition.class, "Postcondition", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPostcondition_Operation(), this.getOperation(), null, "operation", null, 0, 1,
				Postcondition.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(opWithReturnLinkEClass, OpWithReturnLink.class, "OpWithReturnLink", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(findObjectEClass, FindObject.class, "FindObject", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getFindObject_Condition(), this.getCompare(), null, "condition", null, 0, -1, FindObject.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(findObjectsEClass, FindObjects.class, "FindObjects", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getFindObjects_Condition(), this.getCompare(), null, "condition", null, 0, -1, FindObjects.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(compareEClass, Compare.class, "Compare", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCompare_Op(), this.getCompareType(), "op", null, 0, 1, Compare.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCompare_Subject(), this.getOpWithReturnAttr(), null, "subject", null, 0, 1, Compare.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCompare_Object(), this.getOpWithReturnAttr(), null, "object", null, 0, 1, Compare.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(createObjectEClass, CreateObject.class, "CreateObject", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCreateObject_ObName(), ecorePackage.getEString(), "obName", null, 0, 1, CreateObject.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(addObjectEClass, AddObject.class, "AddObject", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAddObject_ObName(), ecorePackage.getEString(), "obName", null, 0, 1, AddObject.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAddObject_Obj(), this.getOpWithReturnLink(), null, "obj", null, 0, 1, AddObject.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(releaseObjectEClass, ReleaseObject.class, "ReleaseObject", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getReleaseObject_ObName(), ecorePackage.getEString(), "obName", null, 0, 1, ReleaseObject.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getReleaseObject_Obj(), this.getOpWithReturnLink(), null, "obj", null, 0, 1, ReleaseObject.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(getAttributeEClass, GetAttribute.class, "GetAttribute", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getGetAttribute_AttrName(), ecorePackage.getEString(), "attrName", null, 0, 1,
				GetAttribute.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(opWithoutReturnEClass, OpWithoutReturn.class, "OpWithoutReturn", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(setAttributeEClass, SetAttribute.class, "SetAttribute", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSetAttribute_AttrName(), ecorePackage.getEString(), "attrName", null, 0, 1,
				SetAttribute.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getSetAttribute_Value(), this.getOpWithReturnAttr(), null, "value", null, 0, 1,
				SetAttribute.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(findLinkedObjectEClass, FindLinkedObject.class, "FindLinkedObject", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getFindLinkedObject_ObName(), ecorePackage.getEString(), "obName", null, 0, 1,
				FindLinkedObject.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getFindLinkedObject_Condition(), this.getCompare(), null, "condition", null, 0, -1,
				FindLinkedObject.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(findLinkedObjectsEClass, FindLinkedObjects.class, "FindLinkedObjects", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getFindLinkedObjects_ObName(), ecorePackage.getEString(), "obName", null, 0, 1,
				FindLinkedObjects.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getFindLinkedObjects_Condition(), this.getCompare(), null, "condition", null, 0, -1,
				FindLinkedObjects.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(addLinkOneToOneEClass, AddLinkOneToOne.class, "AddLinkOneToOne", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAddLinkOneToOne_LinkName(), ecorePackage.getEString(), "linkName", null, 0, 1,
				AddLinkOneToOne.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getAddLinkOneToOne_Ref(), this.getOpWithReturnLink(), null, "ref", null, 0, 1,
				AddLinkOneToOne.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(opWithReturnAttrEClass, OpWithReturnAttr.class, "OpWithReturnAttr", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(opWithReturnLinksEClass, OpWithReturnLinks.class, "OpWithReturnLinks", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(addLinkOneToManyEClass, AddLinkOneToMany.class, "AddLinkOneToMany", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAddLinkOneToMany_LinkName(), ecorePackage.getEString(), "linkName", null, 0, 1,
				AddLinkOneToMany.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getAddLinkOneToMany_Ref(), this.getOpWithReturnLink(), null, "ref", null, 0, 1,
				AddLinkOneToMany.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(removeLinkOneToOneEClass, RemoveLinkOneToOne.class, "RemoveLinkOneToOne", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getRemoveLinkOneToOne_LinkName(), ecorePackage.getEString(), "linkName", null, 0, 1,
				RemoveLinkOneToOne.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getRemoveLinkOneToOne_Ref(), this.getOpWithReturnLink(), null, "ref", null, 0, 1,
				RemoveLinkOneToOne.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(removeLinkOneToManyEClass, RemoveLinkOneToMany.class, "RemoveLinkOneToMany", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getRemoveLinkOneToMany_LinkName(), ecorePackage.getEString(), "linkName", null, 0, 1,
				RemoveLinkOneToMany.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRemoveLinkOneToMany_Ref(), this.getOpWithReturnLink(), null, "ref", null, 0, 1,
				RemoveLinkOneToMany.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(literalEClass, Literal.class, "Literal", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getLiteral_Value(), ecorePackage.getEString(), "value", null, 0, 1, Literal.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(opWithReturnEClass, OpWithReturn.class, "OpWithReturn", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(thirdPartyServiceEClass, ThirdPartyService.class, "ThirdPartyService", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getThirdPartyService_ServiceName(), ecorePackage.getEString(), "serviceName", null, 0, 1,
				ThirdPartyService.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getThirdPartyService_Param(), this.getOpWithReturn(), null, "param", null, 0, -1,
				ThirdPartyService.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(oclIsUndefinedEClass, OCLIsUndefined.class, "OCLIsUndefined", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getOCLIsUndefined_Subject(), ecorePackage.getEString(), "subject", null, 0, 1,
				OCLIsUndefined.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(notEmptyEClass, NotEmpty.class, "NotEmpty", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getNotEmpty_Subject(), ecorePackage.getEString(), "subject", null, 0, 1, NotEmpty.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(setReturnEClass, SetReturn.class, "SetReturn", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSetReturn_Return(), ecorePackage.getEString(), "return", null, 0, 1, SetReturn.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(operationEClass, Operation.class, "Operation", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getOperation_Prev_conj(), this.getConjunction(), this.getConjunction_Prev(), "prev_conj", null,
				0, 1, Operation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getOperation_Next_conj(), this.getConjunction(), this.getConjunction_Next(), "next_conj", null,
				0, 1, Operation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(ifExpressionEClass, IfExpression.class, "IfExpression", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(forAllEClass, ForAll.class, "ForAll", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getForAll_Subject(), ecorePackage.getEString(), "subject", null, 0, 1, ForAll.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(conditionEClass, Condition.class, "Condition", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCondition_Operation(), this.getOperation(), null, "operation", null, 0, 1, Condition.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCondition_Ifexpression(), this.getIfExpression(), null, "ifexpression", null, 0, 1,
				Condition.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(thenEClass, Then.class, "Then", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getThen_Operation(), this.getOperation(), null, "operation", null, 0, 1, Then.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getThen_Ifexpression(), this.getIfExpression(), null, "ifexpression", null, 0, 1, Then.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(elseEClass, Else.class, "Else", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getElse_Operation(), this.getOperation(), null, "operation", null, 0, 1, Else.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getElse_Ifexpression(), this.getIfExpression(), null, "ifexpression", null, 0, 1, Else.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(basicElementEClass, BasicElement.class, "BasicElement", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(conjunctionEClass, Conjunction.class, "Conjunction", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getConjunction_Op(), this.getLogicOperation(), "op", null, 0, 1, Conjunction.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getConjunction_Prev(), this.getOperation(), this.getOperation_Prev_conj(), "prev", null, 0, 1,
				Conjunction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getConjunction_Next(), this.getOperation(), this.getOperation_Next_conj(), "next", null, 0, 1,
				Conjunction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(compareTypeEEnum, CompareType.class, "CompareType");
		addEEnumLiteral(compareTypeEEnum, CompareType.LT);
		addEEnumLiteral(compareTypeEEnum, CompareType.LE);
		addEEnumLiteral(compareTypeEEnum, CompareType.EQ);
		addEEnumLiteral(compareTypeEEnum, CompareType.NE);
		addEEnumLiteral(compareTypeEEnum, CompareType.GE);
		addEEnumLiteral(compareTypeEEnum, CompareType.GT);

		initEEnum(logicOperationEEnum, LogicOperation.class, "LogicOperation");
		addEEnumLiteral(logicOperationEEnum, LogicOperation.AND);
		addEEnumLiteral(logicOperationEEnum, LogicOperation.OR);

		// Create resource
		createResource(eNS_URI);
	}

} //Ocl_finalPackageImpl
