/**
 */
package ocl_final.impl;

import java.util.Collection;

import ocl_final.BasicElement;
import ocl_final.OCL;
import ocl_final.Ocl_finalPackage;
import ocl_final.Operation;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>OCL</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ocl_final.impl.OCLImpl#getBasicelement <em>Basicelement</em>}</li>
 *   <li>{@link ocl_final.impl.OCLImpl#getOperation <em>Operation</em>}</li>
 * </ul>
 *
 * @generated
 */
public class OCLImpl extends MinimalEObjectImpl.Container implements OCL {
	/**
	 * The cached value of the '{@link #getBasicelement() <em>Basicelement</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBasicelement()
	 * @generated
	 * @ordered
	 */
	protected EList<BasicElement> basicelement;

	/**
	 * The cached value of the '{@link #getOperation() <em>Operation</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOperation()
	 * @generated
	 * @ordered
	 */
	protected EList<Operation> operation;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OCLImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ocl_finalPackage.Literals.OCL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<BasicElement> getBasicelement() {
		if (basicelement == null) {
			basicelement = new EObjectContainmentEList<BasicElement>(BasicElement.class, this,
					Ocl_finalPackage.OCL__BASICELEMENT);
		}
		return basicelement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Operation> getOperation() {
		if (operation == null) {
			operation = new EObjectContainmentEList<Operation>(Operation.class, this, Ocl_finalPackage.OCL__OPERATION);
		}
		return operation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Ocl_finalPackage.OCL__BASICELEMENT:
			return ((InternalEList<?>) getBasicelement()).basicRemove(otherEnd, msgs);
		case Ocl_finalPackage.OCL__OPERATION:
			return ((InternalEList<?>) getOperation()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Ocl_finalPackage.OCL__BASICELEMENT:
			return getBasicelement();
		case Ocl_finalPackage.OCL__OPERATION:
			return getOperation();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Ocl_finalPackage.OCL__BASICELEMENT:
			getBasicelement().clear();
			getBasicelement().addAll((Collection<? extends BasicElement>) newValue);
			return;
		case Ocl_finalPackage.OCL__OPERATION:
			getOperation().clear();
			getOperation().addAll((Collection<? extends Operation>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Ocl_finalPackage.OCL__BASICELEMENT:
			getBasicelement().clear();
			return;
		case Ocl_finalPackage.OCL__OPERATION:
			getOperation().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Ocl_finalPackage.OCL__BASICELEMENT:
			return basicelement != null && !basicelement.isEmpty();
		case Ocl_finalPackage.OCL__OPERATION:
			return operation != null && !operation.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //OCLImpl
