/**
 */
package ocl_final.impl;

import java.util.Collection;

import ocl_final.Compare;
import ocl_final.FindLinkedObject;
import ocl_final.Ocl_finalPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Find Linked Object</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ocl_final.impl.FindLinkedObjectImpl#getObName <em>Ob Name</em>}</li>
 *   <li>{@link ocl_final.impl.FindLinkedObjectImpl#getCondition <em>Condition</em>}</li>
 * </ul>
 *
 * @generated
 */
public class FindLinkedObjectImpl extends OpWithReturnLinkImpl implements FindLinkedObject {
	/**
	 * The default value of the '{@link #getObName() <em>Ob Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getObName()
	 * @generated
	 * @ordered
	 */
	protected static final String OB_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getObName() <em>Ob Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getObName()
	 * @generated
	 * @ordered
	 */
	protected String obName = OB_NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getCondition() <em>Condition</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCondition()
	 * @generated
	 * @ordered
	 */
	protected EList<Compare> condition;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FindLinkedObjectImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ocl_finalPackage.Literals.FIND_LINKED_OBJECT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getObName() {
		return obName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setObName(String newObName) {
		String oldObName = obName;
		obName = newObName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ocl_finalPackage.FIND_LINKED_OBJECT__OB_NAME,
					oldObName, obName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Compare> getCondition() {
		if (condition == null) {
			condition = new EObjectResolvingEList<Compare>(Compare.class, this,
					Ocl_finalPackage.FIND_LINKED_OBJECT__CONDITION);
		}
		return condition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Ocl_finalPackage.FIND_LINKED_OBJECT__OB_NAME:
			return getObName();
		case Ocl_finalPackage.FIND_LINKED_OBJECT__CONDITION:
			return getCondition();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Ocl_finalPackage.FIND_LINKED_OBJECT__OB_NAME:
			setObName((String) newValue);
			return;
		case Ocl_finalPackage.FIND_LINKED_OBJECT__CONDITION:
			getCondition().clear();
			getCondition().addAll((Collection<? extends Compare>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Ocl_finalPackage.FIND_LINKED_OBJECT__OB_NAME:
			setObName(OB_NAME_EDEFAULT);
			return;
		case Ocl_finalPackage.FIND_LINKED_OBJECT__CONDITION:
			getCondition().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Ocl_finalPackage.FIND_LINKED_OBJECT__OB_NAME:
			return OB_NAME_EDEFAULT == null ? obName != null : !OB_NAME_EDEFAULT.equals(obName);
		case Ocl_finalPackage.FIND_LINKED_OBJECT__CONDITION:
			return condition != null && !condition.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (obName: ");
		result.append(obName);
		result.append(')');
		return result.toString();
	}

} //FindLinkedObjectImpl
