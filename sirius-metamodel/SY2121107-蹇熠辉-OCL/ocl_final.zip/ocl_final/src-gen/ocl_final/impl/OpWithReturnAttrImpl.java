/**
 */
package ocl_final.impl;

import ocl_final.Ocl_finalPackage;
import ocl_final.OpWithReturnAttr;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Op With Return Attr</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class OpWithReturnAttrImpl extends OpWithReturnImpl implements OpWithReturnAttr {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OpWithReturnAttrImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ocl_finalPackage.Literals.OP_WITH_RETURN_ATTR;
	}

} //OpWithReturnAttrImpl
