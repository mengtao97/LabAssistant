/**
 */
package ocl_final.impl;

import ocl_final.Else;
import ocl_final.IfExpression;
import ocl_final.Ocl_finalPackage;
import ocl_final.Operation;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Else</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ocl_final.impl.ElseImpl#getOperation <em>Operation</em>}</li>
 *   <li>{@link ocl_final.impl.ElseImpl#getIfexpression <em>Ifexpression</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ElseImpl extends BasicElementImpl implements Else {
	/**
	 * The cached value of the '{@link #getOperation() <em>Operation</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOperation()
	 * @generated
	 * @ordered
	 */
	protected Operation operation;

	/**
	 * The cached value of the '{@link #getIfexpression() <em>Ifexpression</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIfexpression()
	 * @generated
	 * @ordered
	 */
	protected IfExpression ifexpression;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ElseImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ocl_finalPackage.Literals.ELSE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Operation getOperation() {
		if (operation != null && operation.eIsProxy()) {
			InternalEObject oldOperation = (InternalEObject) operation;
			operation = (Operation) eResolveProxy(oldOperation);
			if (operation != oldOperation) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Ocl_finalPackage.ELSE__OPERATION,
							oldOperation, operation));
			}
		}
		return operation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Operation basicGetOperation() {
		return operation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOperation(Operation newOperation) {
		Operation oldOperation = operation;
		operation = newOperation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ocl_finalPackage.ELSE__OPERATION, oldOperation,
					operation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IfExpression getIfexpression() {
		if (ifexpression != null && ifexpression.eIsProxy()) {
			InternalEObject oldIfexpression = (InternalEObject) ifexpression;
			ifexpression = (IfExpression) eResolveProxy(oldIfexpression);
			if (ifexpression != oldIfexpression) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Ocl_finalPackage.ELSE__IFEXPRESSION,
							oldIfexpression, ifexpression));
			}
		}
		return ifexpression;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IfExpression basicGetIfexpression() {
		return ifexpression;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIfexpression(IfExpression newIfexpression) {
		IfExpression oldIfexpression = ifexpression;
		ifexpression = newIfexpression;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ocl_finalPackage.ELSE__IFEXPRESSION, oldIfexpression,
					ifexpression));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Ocl_finalPackage.ELSE__OPERATION:
			if (resolve)
				return getOperation();
			return basicGetOperation();
		case Ocl_finalPackage.ELSE__IFEXPRESSION:
			if (resolve)
				return getIfexpression();
			return basicGetIfexpression();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Ocl_finalPackage.ELSE__OPERATION:
			setOperation((Operation) newValue);
			return;
		case Ocl_finalPackage.ELSE__IFEXPRESSION:
			setIfexpression((IfExpression) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Ocl_finalPackage.ELSE__OPERATION:
			setOperation((Operation) null);
			return;
		case Ocl_finalPackage.ELSE__IFEXPRESSION:
			setIfexpression((IfExpression) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Ocl_finalPackage.ELSE__OPERATION:
			return operation != null;
		case Ocl_finalPackage.ELSE__IFEXPRESSION:
			return ifexpression != null;
		}
		return super.eIsSet(featureID);
	}

} //ElseImpl
