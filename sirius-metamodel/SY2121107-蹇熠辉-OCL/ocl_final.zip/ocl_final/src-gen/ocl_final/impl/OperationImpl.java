/**
 */
package ocl_final.impl;

import ocl_final.Conjunction;
import ocl_final.Ocl_finalPackage;
import ocl_final.Operation;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Operation</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ocl_final.impl.OperationImpl#getPrev_conj <em>Prev conj</em>}</li>
 *   <li>{@link ocl_final.impl.OperationImpl#getNext_conj <em>Next conj</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class OperationImpl extends MinimalEObjectImpl.Container implements Operation {
	/**
	 * The cached value of the '{@link #getPrev_conj() <em>Prev conj</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrev_conj()
	 * @generated
	 * @ordered
	 */
	protected Conjunction prev_conj;

	/**
	 * The cached value of the '{@link #getNext_conj() <em>Next conj</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNext_conj()
	 * @generated
	 * @ordered
	 */
	protected Conjunction next_conj;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OperationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ocl_finalPackage.Literals.OPERATION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Conjunction getPrev_conj() {
		if (prev_conj != null && prev_conj.eIsProxy()) {
			InternalEObject oldPrev_conj = (InternalEObject) prev_conj;
			prev_conj = (Conjunction) eResolveProxy(oldPrev_conj);
			if (prev_conj != oldPrev_conj) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Ocl_finalPackage.OPERATION__PREV_CONJ,
							oldPrev_conj, prev_conj));
			}
		}
		return prev_conj;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Conjunction basicGetPrev_conj() {
		return prev_conj;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPrev_conj(Conjunction newPrev_conj, NotificationChain msgs) {
		Conjunction oldPrev_conj = prev_conj;
		prev_conj = newPrev_conj;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Ocl_finalPackage.OPERATION__PREV_CONJ, oldPrev_conj, newPrev_conj);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPrev_conj(Conjunction newPrev_conj) {
		if (newPrev_conj != prev_conj) {
			NotificationChain msgs = null;
			if (prev_conj != null)
				msgs = ((InternalEObject) prev_conj).eInverseRemove(this, Ocl_finalPackage.CONJUNCTION__PREV,
						Conjunction.class, msgs);
			if (newPrev_conj != null)
				msgs = ((InternalEObject) newPrev_conj).eInverseAdd(this, Ocl_finalPackage.CONJUNCTION__PREV,
						Conjunction.class, msgs);
			msgs = basicSetPrev_conj(newPrev_conj, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ocl_finalPackage.OPERATION__PREV_CONJ, newPrev_conj,
					newPrev_conj));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Conjunction getNext_conj() {
		if (next_conj != null && next_conj.eIsProxy()) {
			InternalEObject oldNext_conj = (InternalEObject) next_conj;
			next_conj = (Conjunction) eResolveProxy(oldNext_conj);
			if (next_conj != oldNext_conj) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Ocl_finalPackage.OPERATION__NEXT_CONJ,
							oldNext_conj, next_conj));
			}
		}
		return next_conj;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Conjunction basicGetNext_conj() {
		return next_conj;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetNext_conj(Conjunction newNext_conj, NotificationChain msgs) {
		Conjunction oldNext_conj = next_conj;
		next_conj = newNext_conj;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Ocl_finalPackage.OPERATION__NEXT_CONJ, oldNext_conj, newNext_conj);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNext_conj(Conjunction newNext_conj) {
		if (newNext_conj != next_conj) {
			NotificationChain msgs = null;
			if (next_conj != null)
				msgs = ((InternalEObject) next_conj).eInverseRemove(this, Ocl_finalPackage.CONJUNCTION__NEXT,
						Conjunction.class, msgs);
			if (newNext_conj != null)
				msgs = ((InternalEObject) newNext_conj).eInverseAdd(this, Ocl_finalPackage.CONJUNCTION__NEXT,
						Conjunction.class, msgs);
			msgs = basicSetNext_conj(newNext_conj, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ocl_finalPackage.OPERATION__NEXT_CONJ, newNext_conj,
					newNext_conj));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Ocl_finalPackage.OPERATION__PREV_CONJ:
			if (prev_conj != null)
				msgs = ((InternalEObject) prev_conj).eInverseRemove(this, Ocl_finalPackage.CONJUNCTION__PREV,
						Conjunction.class, msgs);
			return basicSetPrev_conj((Conjunction) otherEnd, msgs);
		case Ocl_finalPackage.OPERATION__NEXT_CONJ:
			if (next_conj != null)
				msgs = ((InternalEObject) next_conj).eInverseRemove(this, Ocl_finalPackage.CONJUNCTION__NEXT,
						Conjunction.class, msgs);
			return basicSetNext_conj((Conjunction) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Ocl_finalPackage.OPERATION__PREV_CONJ:
			return basicSetPrev_conj(null, msgs);
		case Ocl_finalPackage.OPERATION__NEXT_CONJ:
			return basicSetNext_conj(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Ocl_finalPackage.OPERATION__PREV_CONJ:
			if (resolve)
				return getPrev_conj();
			return basicGetPrev_conj();
		case Ocl_finalPackage.OPERATION__NEXT_CONJ:
			if (resolve)
				return getNext_conj();
			return basicGetNext_conj();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Ocl_finalPackage.OPERATION__PREV_CONJ:
			setPrev_conj((Conjunction) newValue);
			return;
		case Ocl_finalPackage.OPERATION__NEXT_CONJ:
			setNext_conj((Conjunction) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Ocl_finalPackage.OPERATION__PREV_CONJ:
			setPrev_conj((Conjunction) null);
			return;
		case Ocl_finalPackage.OPERATION__NEXT_CONJ:
			setNext_conj((Conjunction) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Ocl_finalPackage.OPERATION__PREV_CONJ:
			return prev_conj != null;
		case Ocl_finalPackage.OPERATION__NEXT_CONJ:
			return next_conj != null;
		}
		return super.eIsSet(featureID);
	}

} //OperationImpl
