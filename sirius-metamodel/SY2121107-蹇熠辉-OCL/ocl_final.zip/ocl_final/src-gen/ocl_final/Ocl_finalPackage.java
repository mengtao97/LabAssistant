/**
 */
package ocl_final;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see ocl_final.Ocl_finalFactory
 * @model kind="package"
 * @generated
 */
public interface Ocl_finalPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "ocl_final";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/ocl_final";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "ocl_final";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	Ocl_finalPackage eINSTANCE = ocl_final.impl.Ocl_finalPackageImpl.init();

	/**
	 * The meta object id for the '{@link ocl_final.impl.OCLImpl <em>OCL</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.OCLImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getOCL()
	 * @generated
	 */
	int OCL = 0;

	/**
	 * The feature id for the '<em><b>Basicelement</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OCL__BASICELEMENT = 0;

	/**
	 * The feature id for the '<em><b>Operation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OCL__OPERATION = 1;

	/**
	 * The number of structural features of the '<em>OCL</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OCL_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>OCL</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OCL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.BasicElementImpl <em>Basic Element</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.BasicElementImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getBasicElement()
	 * @generated
	 */
	int BASIC_ELEMENT = 34;

	/**
	 * The number of structural features of the '<em>Basic Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASIC_ELEMENT_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Basic Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASIC_ELEMENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.ContractImpl <em>Contract</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.ContractImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getContract()
	 * @generated
	 */
	int CONTRACT = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTRACT__NAME = BASIC_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Postcondition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTRACT__POSTCONDITION = BASIC_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Precondition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTRACT__PRECONDITION = BASIC_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Service</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTRACT__SERVICE = BASIC_ELEMENT_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Contract</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTRACT_FEATURE_COUNT = BASIC_ELEMENT_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>Contract</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTRACT_OPERATION_COUNT = BASIC_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.PreconditionImpl <em>Precondition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.PreconditionImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getPrecondition()
	 * @generated
	 */
	int PRECONDITION = 2;

	/**
	 * The feature id for the '<em><b>Operation</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRECONDITION__OPERATION = BASIC_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Precondition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRECONDITION_FEATURE_COUNT = BASIC_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Precondition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRECONDITION_OPERATION_COUNT = BASIC_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.PostconditionImpl <em>Postcondition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.PostconditionImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getPostcondition()
	 * @generated
	 */
	int POSTCONDITION = 3;

	/**
	 * The feature id for the '<em><b>Operation</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSTCONDITION__OPERATION = BASIC_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Postcondition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSTCONDITION_FEATURE_COUNT = BASIC_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Postcondition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSTCONDITION_OPERATION_COUNT = BASIC_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.OperationImpl <em>Operation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.OperationImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getOperation()
	 * @generated
	 */
	int OPERATION = 28;

	/**
	 * The feature id for the '<em><b>Prev conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATION__PREV_CONJ = 0;

	/**
	 * The feature id for the '<em><b>Next conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATION__NEXT_CONJ = 1;

	/**
	 * The number of structural features of the '<em>Operation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATION_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Operation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.OpWithReturnImpl <em>Op With Return</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.OpWithReturnImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getOpWithReturn()
	 * @generated
	 */
	int OP_WITH_RETURN = 23;

	/**
	 * The feature id for the '<em><b>Prev conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OP_WITH_RETURN__PREV_CONJ = OPERATION__PREV_CONJ;

	/**
	 * The feature id for the '<em><b>Next conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OP_WITH_RETURN__NEXT_CONJ = OPERATION__NEXT_CONJ;

	/**
	 * The number of structural features of the '<em>Op With Return</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OP_WITH_RETURN_FEATURE_COUNT = OPERATION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Op With Return</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OP_WITH_RETURN_OPERATION_COUNT = OPERATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.OpWithReturnLinkImpl <em>Op With Return Link</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.OpWithReturnLinkImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getOpWithReturnLink()
	 * @generated
	 */
	int OP_WITH_RETURN_LINK = 4;

	/**
	 * The feature id for the '<em><b>Prev conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OP_WITH_RETURN_LINK__PREV_CONJ = OP_WITH_RETURN__PREV_CONJ;

	/**
	 * The feature id for the '<em><b>Next conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OP_WITH_RETURN_LINK__NEXT_CONJ = OP_WITH_RETURN__NEXT_CONJ;

	/**
	 * The number of structural features of the '<em>Op With Return Link</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OP_WITH_RETURN_LINK_FEATURE_COUNT = OP_WITH_RETURN_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Op With Return Link</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OP_WITH_RETURN_LINK_OPERATION_COUNT = OP_WITH_RETURN_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.FindObjectImpl <em>Find Object</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.FindObjectImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getFindObject()
	 * @generated
	 */
	int FIND_OBJECT = 5;

	/**
	 * The feature id for the '<em><b>Prev conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIND_OBJECT__PREV_CONJ = OP_WITH_RETURN_LINK__PREV_CONJ;

	/**
	 * The feature id for the '<em><b>Next conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIND_OBJECT__NEXT_CONJ = OP_WITH_RETURN_LINK__NEXT_CONJ;

	/**
	 * The feature id for the '<em><b>Condition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIND_OBJECT__CONDITION = OP_WITH_RETURN_LINK_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Find Object</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIND_OBJECT_FEATURE_COUNT = OP_WITH_RETURN_LINK_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Find Object</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIND_OBJECT_OPERATION_COUNT = OP_WITH_RETURN_LINK_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.OpWithReturnLinksImpl <em>Op With Return Links</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.OpWithReturnLinksImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getOpWithReturnLinks()
	 * @generated
	 */
	int OP_WITH_RETURN_LINKS = 18;

	/**
	 * The feature id for the '<em><b>Prev conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OP_WITH_RETURN_LINKS__PREV_CONJ = OP_WITH_RETURN__PREV_CONJ;

	/**
	 * The feature id for the '<em><b>Next conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OP_WITH_RETURN_LINKS__NEXT_CONJ = OP_WITH_RETURN__NEXT_CONJ;

	/**
	 * The number of structural features of the '<em>Op With Return Links</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OP_WITH_RETURN_LINKS_FEATURE_COUNT = OP_WITH_RETURN_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Op With Return Links</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OP_WITH_RETURN_LINKS_OPERATION_COUNT = OP_WITH_RETURN_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.FindObjectsImpl <em>Find Objects</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.FindObjectsImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getFindObjects()
	 * @generated
	 */
	int FIND_OBJECTS = 6;

	/**
	 * The feature id for the '<em><b>Prev conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIND_OBJECTS__PREV_CONJ = OP_WITH_RETURN_LINKS__PREV_CONJ;

	/**
	 * The feature id for the '<em><b>Next conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIND_OBJECTS__NEXT_CONJ = OP_WITH_RETURN_LINKS__NEXT_CONJ;

	/**
	 * The feature id for the '<em><b>Condition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIND_OBJECTS__CONDITION = OP_WITH_RETURN_LINKS_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Find Objects</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIND_OBJECTS_FEATURE_COUNT = OP_WITH_RETURN_LINKS_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Find Objects</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIND_OBJECTS_OPERATION_COUNT = OP_WITH_RETURN_LINKS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.OpWithoutReturnImpl <em>Op Without Return</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.OpWithoutReturnImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getOpWithoutReturn()
	 * @generated
	 */
	int OP_WITHOUT_RETURN = 12;

	/**
	 * The feature id for the '<em><b>Prev conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OP_WITHOUT_RETURN__PREV_CONJ = OPERATION__PREV_CONJ;

	/**
	 * The feature id for the '<em><b>Next conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OP_WITHOUT_RETURN__NEXT_CONJ = OPERATION__NEXT_CONJ;

	/**
	 * The number of structural features of the '<em>Op Without Return</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OP_WITHOUT_RETURN_FEATURE_COUNT = OPERATION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Op Without Return</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OP_WITHOUT_RETURN_OPERATION_COUNT = OPERATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.CompareImpl <em>Compare</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.CompareImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getCompare()
	 * @generated
	 */
	int COMPARE = 7;

	/**
	 * The feature id for the '<em><b>Prev conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPARE__PREV_CONJ = OP_WITHOUT_RETURN__PREV_CONJ;

	/**
	 * The feature id for the '<em><b>Next conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPARE__NEXT_CONJ = OP_WITHOUT_RETURN__NEXT_CONJ;

	/**
	 * The feature id for the '<em><b>Op</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPARE__OP = OP_WITHOUT_RETURN_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Subject</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPARE__SUBJECT = OP_WITHOUT_RETURN_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Object</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPARE__OBJECT = OP_WITHOUT_RETURN_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Compare</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPARE_FEATURE_COUNT = OP_WITHOUT_RETURN_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Compare</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPARE_OPERATION_COUNT = OP_WITHOUT_RETURN_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.CreateObjectImpl <em>Create Object</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.CreateObjectImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getCreateObject()
	 * @generated
	 */
	int CREATE_OBJECT = 8;

	/**
	 * The feature id for the '<em><b>Prev conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_OBJECT__PREV_CONJ = OP_WITHOUT_RETURN__PREV_CONJ;

	/**
	 * The feature id for the '<em><b>Next conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_OBJECT__NEXT_CONJ = OP_WITHOUT_RETURN__NEXT_CONJ;

	/**
	 * The feature id for the '<em><b>Ob Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_OBJECT__OB_NAME = OP_WITHOUT_RETURN_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Create Object</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_OBJECT_FEATURE_COUNT = OP_WITHOUT_RETURN_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Create Object</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_OBJECT_OPERATION_COUNT = OP_WITHOUT_RETURN_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.AddObjectImpl <em>Add Object</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.AddObjectImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getAddObject()
	 * @generated
	 */
	int ADD_OBJECT = 9;

	/**
	 * The feature id for the '<em><b>Prev conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADD_OBJECT__PREV_CONJ = OP_WITHOUT_RETURN__PREV_CONJ;

	/**
	 * The feature id for the '<em><b>Next conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADD_OBJECT__NEXT_CONJ = OP_WITHOUT_RETURN__NEXT_CONJ;

	/**
	 * The feature id for the '<em><b>Ob Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADD_OBJECT__OB_NAME = OP_WITHOUT_RETURN_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Obj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADD_OBJECT__OBJ = OP_WITHOUT_RETURN_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Add Object</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADD_OBJECT_FEATURE_COUNT = OP_WITHOUT_RETURN_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Add Object</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADD_OBJECT_OPERATION_COUNT = OP_WITHOUT_RETURN_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.ReleaseObjectImpl <em>Release Object</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.ReleaseObjectImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getReleaseObject()
	 * @generated
	 */
	int RELEASE_OBJECT = 10;

	/**
	 * The feature id for the '<em><b>Prev conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RELEASE_OBJECT__PREV_CONJ = OP_WITHOUT_RETURN__PREV_CONJ;

	/**
	 * The feature id for the '<em><b>Next conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RELEASE_OBJECT__NEXT_CONJ = OP_WITHOUT_RETURN__NEXT_CONJ;

	/**
	 * The feature id for the '<em><b>Ob Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RELEASE_OBJECT__OB_NAME = OP_WITHOUT_RETURN_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Obj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RELEASE_OBJECT__OBJ = OP_WITHOUT_RETURN_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Release Object</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RELEASE_OBJECT_FEATURE_COUNT = OP_WITHOUT_RETURN_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Release Object</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RELEASE_OBJECT_OPERATION_COUNT = OP_WITHOUT_RETURN_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.OpWithReturnAttrImpl <em>Op With Return Attr</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.OpWithReturnAttrImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getOpWithReturnAttr()
	 * @generated
	 */
	int OP_WITH_RETURN_ATTR = 17;

	/**
	 * The feature id for the '<em><b>Prev conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OP_WITH_RETURN_ATTR__PREV_CONJ = OP_WITH_RETURN__PREV_CONJ;

	/**
	 * The feature id for the '<em><b>Next conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OP_WITH_RETURN_ATTR__NEXT_CONJ = OP_WITH_RETURN__NEXT_CONJ;

	/**
	 * The number of structural features of the '<em>Op With Return Attr</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OP_WITH_RETURN_ATTR_FEATURE_COUNT = OP_WITH_RETURN_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Op With Return Attr</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OP_WITH_RETURN_ATTR_OPERATION_COUNT = OP_WITH_RETURN_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.GetAttributeImpl <em>Get Attribute</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.GetAttributeImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getGetAttribute()
	 * @generated
	 */
	int GET_ATTRIBUTE = 11;

	/**
	 * The feature id for the '<em><b>Prev conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GET_ATTRIBUTE__PREV_CONJ = OP_WITH_RETURN_ATTR__PREV_CONJ;

	/**
	 * The feature id for the '<em><b>Next conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GET_ATTRIBUTE__NEXT_CONJ = OP_WITH_RETURN_ATTR__NEXT_CONJ;

	/**
	 * The feature id for the '<em><b>Attr Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GET_ATTRIBUTE__ATTR_NAME = OP_WITH_RETURN_ATTR_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Get Attribute</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GET_ATTRIBUTE_FEATURE_COUNT = OP_WITH_RETURN_ATTR_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Get Attribute</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GET_ATTRIBUTE_OPERATION_COUNT = OP_WITH_RETURN_ATTR_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.SetAttributeImpl <em>Set Attribute</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.SetAttributeImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getSetAttribute()
	 * @generated
	 */
	int SET_ATTRIBUTE = 13;

	/**
	 * The feature id for the '<em><b>Prev conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SET_ATTRIBUTE__PREV_CONJ = OP_WITHOUT_RETURN__PREV_CONJ;

	/**
	 * The feature id for the '<em><b>Next conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SET_ATTRIBUTE__NEXT_CONJ = OP_WITHOUT_RETURN__NEXT_CONJ;

	/**
	 * The feature id for the '<em><b>Attr Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SET_ATTRIBUTE__ATTR_NAME = OP_WITHOUT_RETURN_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Value</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SET_ATTRIBUTE__VALUE = OP_WITHOUT_RETURN_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Set Attribute</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SET_ATTRIBUTE_FEATURE_COUNT = OP_WITHOUT_RETURN_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Set Attribute</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SET_ATTRIBUTE_OPERATION_COUNT = OP_WITHOUT_RETURN_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.FindLinkedObjectImpl <em>Find Linked Object</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.FindLinkedObjectImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getFindLinkedObject()
	 * @generated
	 */
	int FIND_LINKED_OBJECT = 14;

	/**
	 * The feature id for the '<em><b>Prev conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIND_LINKED_OBJECT__PREV_CONJ = OP_WITH_RETURN_LINK__PREV_CONJ;

	/**
	 * The feature id for the '<em><b>Next conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIND_LINKED_OBJECT__NEXT_CONJ = OP_WITH_RETURN_LINK__NEXT_CONJ;

	/**
	 * The feature id for the '<em><b>Ob Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIND_LINKED_OBJECT__OB_NAME = OP_WITH_RETURN_LINK_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Condition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIND_LINKED_OBJECT__CONDITION = OP_WITH_RETURN_LINK_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Find Linked Object</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIND_LINKED_OBJECT_FEATURE_COUNT = OP_WITH_RETURN_LINK_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Find Linked Object</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIND_LINKED_OBJECT_OPERATION_COUNT = OP_WITH_RETURN_LINK_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.FindLinkedObjectsImpl <em>Find Linked Objects</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.FindLinkedObjectsImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getFindLinkedObjects()
	 * @generated
	 */
	int FIND_LINKED_OBJECTS = 15;

	/**
	 * The feature id for the '<em><b>Prev conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIND_LINKED_OBJECTS__PREV_CONJ = OP_WITH_RETURN_LINKS__PREV_CONJ;

	/**
	 * The feature id for the '<em><b>Next conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIND_LINKED_OBJECTS__NEXT_CONJ = OP_WITH_RETURN_LINKS__NEXT_CONJ;

	/**
	 * The feature id for the '<em><b>Ob Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIND_LINKED_OBJECTS__OB_NAME = OP_WITH_RETURN_LINKS_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Condition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIND_LINKED_OBJECTS__CONDITION = OP_WITH_RETURN_LINKS_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Find Linked Objects</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIND_LINKED_OBJECTS_FEATURE_COUNT = OP_WITH_RETURN_LINKS_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Find Linked Objects</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIND_LINKED_OBJECTS_OPERATION_COUNT = OP_WITH_RETURN_LINKS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.AddLinkOneToOneImpl <em>Add Link One To One</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.AddLinkOneToOneImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getAddLinkOneToOne()
	 * @generated
	 */
	int ADD_LINK_ONE_TO_ONE = 16;

	/**
	 * The feature id for the '<em><b>Prev conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADD_LINK_ONE_TO_ONE__PREV_CONJ = OP_WITHOUT_RETURN__PREV_CONJ;

	/**
	 * The feature id for the '<em><b>Next conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADD_LINK_ONE_TO_ONE__NEXT_CONJ = OP_WITHOUT_RETURN__NEXT_CONJ;

	/**
	 * The feature id for the '<em><b>Link Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADD_LINK_ONE_TO_ONE__LINK_NAME = OP_WITHOUT_RETURN_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Ref</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADD_LINK_ONE_TO_ONE__REF = OP_WITHOUT_RETURN_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Add Link One To One</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADD_LINK_ONE_TO_ONE_FEATURE_COUNT = OP_WITHOUT_RETURN_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Add Link One To One</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADD_LINK_ONE_TO_ONE_OPERATION_COUNT = OP_WITHOUT_RETURN_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.AddLinkOneToManyImpl <em>Add Link One To Many</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.AddLinkOneToManyImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getAddLinkOneToMany()
	 * @generated
	 */
	int ADD_LINK_ONE_TO_MANY = 19;

	/**
	 * The feature id for the '<em><b>Prev conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADD_LINK_ONE_TO_MANY__PREV_CONJ = OP_WITHOUT_RETURN__PREV_CONJ;

	/**
	 * The feature id for the '<em><b>Next conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADD_LINK_ONE_TO_MANY__NEXT_CONJ = OP_WITHOUT_RETURN__NEXT_CONJ;

	/**
	 * The feature id for the '<em><b>Link Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADD_LINK_ONE_TO_MANY__LINK_NAME = OP_WITHOUT_RETURN_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Ref</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADD_LINK_ONE_TO_MANY__REF = OP_WITHOUT_RETURN_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Add Link One To Many</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADD_LINK_ONE_TO_MANY_FEATURE_COUNT = OP_WITHOUT_RETURN_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Add Link One To Many</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADD_LINK_ONE_TO_MANY_OPERATION_COUNT = OP_WITHOUT_RETURN_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.RemoveLinkOneToOneImpl <em>Remove Link One To One</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.RemoveLinkOneToOneImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getRemoveLinkOneToOne()
	 * @generated
	 */
	int REMOVE_LINK_ONE_TO_ONE = 20;

	/**
	 * The feature id for the '<em><b>Prev conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_LINK_ONE_TO_ONE__PREV_CONJ = OP_WITHOUT_RETURN__PREV_CONJ;

	/**
	 * The feature id for the '<em><b>Next conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_LINK_ONE_TO_ONE__NEXT_CONJ = OP_WITHOUT_RETURN__NEXT_CONJ;

	/**
	 * The feature id for the '<em><b>Link Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_LINK_ONE_TO_ONE__LINK_NAME = OP_WITHOUT_RETURN_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Ref</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_LINK_ONE_TO_ONE__REF = OP_WITHOUT_RETURN_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Remove Link One To One</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_LINK_ONE_TO_ONE_FEATURE_COUNT = OP_WITHOUT_RETURN_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Remove Link One To One</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_LINK_ONE_TO_ONE_OPERATION_COUNT = OP_WITHOUT_RETURN_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.RemoveLinkOneToManyImpl <em>Remove Link One To Many</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.RemoveLinkOneToManyImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getRemoveLinkOneToMany()
	 * @generated
	 */
	int REMOVE_LINK_ONE_TO_MANY = 21;

	/**
	 * The feature id for the '<em><b>Prev conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_LINK_ONE_TO_MANY__PREV_CONJ = OP_WITHOUT_RETURN__PREV_CONJ;

	/**
	 * The feature id for the '<em><b>Next conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_LINK_ONE_TO_MANY__NEXT_CONJ = OP_WITHOUT_RETURN__NEXT_CONJ;

	/**
	 * The feature id for the '<em><b>Link Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_LINK_ONE_TO_MANY__LINK_NAME = OP_WITHOUT_RETURN_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Ref</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_LINK_ONE_TO_MANY__REF = OP_WITHOUT_RETURN_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Remove Link One To Many</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_LINK_ONE_TO_MANY_FEATURE_COUNT = OP_WITHOUT_RETURN_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Remove Link One To Many</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REMOVE_LINK_ONE_TO_MANY_OPERATION_COUNT = OP_WITHOUT_RETURN_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.LiteralImpl <em>Literal</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.LiteralImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getLiteral()
	 * @generated
	 */
	int LITERAL = 22;

	/**
	 * The feature id for the '<em><b>Prev conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LITERAL__PREV_CONJ = OP_WITH_RETURN_ATTR__PREV_CONJ;

	/**
	 * The feature id for the '<em><b>Next conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LITERAL__NEXT_CONJ = OP_WITH_RETURN_ATTR__NEXT_CONJ;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LITERAL__VALUE = OP_WITH_RETURN_ATTR_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Literal</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LITERAL_FEATURE_COUNT = OP_WITH_RETURN_ATTR_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Literal</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LITERAL_OPERATION_COUNT = OP_WITH_RETURN_ATTR_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.ThirdPartyServiceImpl <em>Third Party Service</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.ThirdPartyServiceImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getThirdPartyService()
	 * @generated
	 */
	int THIRD_PARTY_SERVICE = 24;

	/**
	 * The feature id for the '<em><b>Prev conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THIRD_PARTY_SERVICE__PREV_CONJ = OP_WITH_RETURN__PREV_CONJ;

	/**
	 * The feature id for the '<em><b>Next conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THIRD_PARTY_SERVICE__NEXT_CONJ = OP_WITH_RETURN__NEXT_CONJ;

	/**
	 * The feature id for the '<em><b>Service Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THIRD_PARTY_SERVICE__SERVICE_NAME = OP_WITH_RETURN_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Param</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THIRD_PARTY_SERVICE__PARAM = OP_WITH_RETURN_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Third Party Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THIRD_PARTY_SERVICE_FEATURE_COUNT = OP_WITH_RETURN_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Third Party Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THIRD_PARTY_SERVICE_OPERATION_COUNT = OP_WITH_RETURN_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.OCLIsUndefinedImpl <em>OCL Is Undefined</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.OCLIsUndefinedImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getOCLIsUndefined()
	 * @generated
	 */
	int OCL_IS_UNDEFINED = 25;

	/**
	 * The feature id for the '<em><b>Prev conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OCL_IS_UNDEFINED__PREV_CONJ = OP_WITH_RETURN_ATTR__PREV_CONJ;

	/**
	 * The feature id for the '<em><b>Next conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OCL_IS_UNDEFINED__NEXT_CONJ = OP_WITH_RETURN_ATTR__NEXT_CONJ;

	/**
	 * The feature id for the '<em><b>Subject</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OCL_IS_UNDEFINED__SUBJECT = OP_WITH_RETURN_ATTR_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>OCL Is Undefined</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OCL_IS_UNDEFINED_FEATURE_COUNT = OP_WITH_RETURN_ATTR_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>OCL Is Undefined</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OCL_IS_UNDEFINED_OPERATION_COUNT = OP_WITH_RETURN_ATTR_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.NotEmptyImpl <em>Not Empty</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.NotEmptyImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getNotEmpty()
	 * @generated
	 */
	int NOT_EMPTY = 26;

	/**
	 * The feature id for the '<em><b>Prev conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NOT_EMPTY__PREV_CONJ = OP_WITH_RETURN_ATTR__PREV_CONJ;

	/**
	 * The feature id for the '<em><b>Next conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NOT_EMPTY__NEXT_CONJ = OP_WITH_RETURN_ATTR__NEXT_CONJ;

	/**
	 * The feature id for the '<em><b>Subject</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NOT_EMPTY__SUBJECT = OP_WITH_RETURN_ATTR_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Not Empty</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NOT_EMPTY_FEATURE_COUNT = OP_WITH_RETURN_ATTR_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Not Empty</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NOT_EMPTY_OPERATION_COUNT = OP_WITH_RETURN_ATTR_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.SetReturnImpl <em>Set Return</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.SetReturnImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getSetReturn()
	 * @generated
	 */
	int SET_RETURN = 27;

	/**
	 * The feature id for the '<em><b>Prev conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SET_RETURN__PREV_CONJ = OP_WITHOUT_RETURN__PREV_CONJ;

	/**
	 * The feature id for the '<em><b>Next conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SET_RETURN__NEXT_CONJ = OP_WITHOUT_RETURN__NEXT_CONJ;

	/**
	 * The feature id for the '<em><b>Return</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SET_RETURN__RETURN = OP_WITHOUT_RETURN_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Set Return</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SET_RETURN_FEATURE_COUNT = OP_WITHOUT_RETURN_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Set Return</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SET_RETURN_OPERATION_COUNT = OP_WITHOUT_RETURN_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.IfExpressionImpl <em>If Expression</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.IfExpressionImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getIfExpression()
	 * @generated
	 */
	int IF_EXPRESSION = 29;

	/**
	 * The feature id for the '<em><b>Prev conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IF_EXPRESSION__PREV_CONJ = OPERATION__PREV_CONJ;

	/**
	 * The feature id for the '<em><b>Next conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IF_EXPRESSION__NEXT_CONJ = OPERATION__NEXT_CONJ;

	/**
	 * The number of structural features of the '<em>If Expression</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IF_EXPRESSION_FEATURE_COUNT = OPERATION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>If Expression</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IF_EXPRESSION_OPERATION_COUNT = OPERATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.ForAllImpl <em>For All</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.ForAllImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getForAll()
	 * @generated
	 */
	int FOR_ALL = 30;

	/**
	 * The feature id for the '<em><b>Prev conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOR_ALL__PREV_CONJ = OP_WITHOUT_RETURN__PREV_CONJ;

	/**
	 * The feature id for the '<em><b>Next conj</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOR_ALL__NEXT_CONJ = OP_WITHOUT_RETURN__NEXT_CONJ;

	/**
	 * The feature id for the '<em><b>Subject</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOR_ALL__SUBJECT = OP_WITHOUT_RETURN_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>For All</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOR_ALL_FEATURE_COUNT = OP_WITHOUT_RETURN_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>For All</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOR_ALL_OPERATION_COUNT = OP_WITHOUT_RETURN_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.ConditionImpl <em>Condition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.ConditionImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getCondition()
	 * @generated
	 */
	int CONDITION = 31;

	/**
	 * The feature id for the '<em><b>Operation</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONDITION__OPERATION = BASIC_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Ifexpression</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONDITION__IFEXPRESSION = BASIC_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Condition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONDITION_FEATURE_COUNT = BASIC_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Condition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONDITION_OPERATION_COUNT = BASIC_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.ThenImpl <em>Then</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.ThenImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getThen()
	 * @generated
	 */
	int THEN = 32;

	/**
	 * The feature id for the '<em><b>Operation</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THEN__OPERATION = BASIC_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Ifexpression</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THEN__IFEXPRESSION = BASIC_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Then</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THEN_FEATURE_COUNT = BASIC_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Then</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THEN_OPERATION_COUNT = BASIC_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.ElseImpl <em>Else</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.ElseImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getElse()
	 * @generated
	 */
	int ELSE = 33;

	/**
	 * The feature id for the '<em><b>Operation</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELSE__OPERATION = BASIC_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Ifexpression</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELSE__IFEXPRESSION = BASIC_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Else</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELSE_FEATURE_COUNT = BASIC_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Else</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELSE_OPERATION_COUNT = BASIC_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.impl.ConjunctionImpl <em>Conjunction</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.impl.ConjunctionImpl
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getConjunction()
	 * @generated
	 */
	int CONJUNCTION = 35;

	/**
	 * The feature id for the '<em><b>Op</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONJUNCTION__OP = BASIC_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Prev</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONJUNCTION__PREV = BASIC_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Next</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONJUNCTION__NEXT = BASIC_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Conjunction</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONJUNCTION_FEATURE_COUNT = BASIC_ELEMENT_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Conjunction</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONJUNCTION_OPERATION_COUNT = BASIC_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ocl_final.CompareType <em>Compare Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.CompareType
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getCompareType()
	 * @generated
	 */
	int COMPARE_TYPE = 36;

	/**
	 * The meta object id for the '{@link ocl_final.LogicOperation <em>Logic Operation</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ocl_final.LogicOperation
	 * @see ocl_final.impl.Ocl_finalPackageImpl#getLogicOperation()
	 * @generated
	 */
	int LOGIC_OPERATION = 37;

	/**
	 * Returns the meta object for class '{@link ocl_final.OCL <em>OCL</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>OCL</em>'.
	 * @see ocl_final.OCL
	 * @generated
	 */
	EClass getOCL();

	/**
	 * Returns the meta object for the containment reference list '{@link ocl_final.OCL#getBasicelement <em>Basicelement</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Basicelement</em>'.
	 * @see ocl_final.OCL#getBasicelement()
	 * @see #getOCL()
	 * @generated
	 */
	EReference getOCL_Basicelement();

	/**
	 * Returns the meta object for the containment reference list '{@link ocl_final.OCL#getOperation <em>Operation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Operation</em>'.
	 * @see ocl_final.OCL#getOperation()
	 * @see #getOCL()
	 * @generated
	 */
	EReference getOCL_Operation();

	/**
	 * Returns the meta object for class '{@link ocl_final.Contract <em>Contract</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Contract</em>'.
	 * @see ocl_final.Contract
	 * @generated
	 */
	EClass getContract();

	/**
	 * Returns the meta object for the attribute '{@link ocl_final.Contract#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see ocl_final.Contract#getName()
	 * @see #getContract()
	 * @generated
	 */
	EAttribute getContract_Name();

	/**
	 * Returns the meta object for the reference '{@link ocl_final.Contract#getPostcondition <em>Postcondition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Postcondition</em>'.
	 * @see ocl_final.Contract#getPostcondition()
	 * @see #getContract()
	 * @generated
	 */
	EReference getContract_Postcondition();

	/**
	 * Returns the meta object for the reference '{@link ocl_final.Contract#getPrecondition <em>Precondition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Precondition</em>'.
	 * @see ocl_final.Contract#getPrecondition()
	 * @see #getContract()
	 * @generated
	 */
	EReference getContract_Precondition();

	/**
	 * Returns the meta object for the attribute '{@link ocl_final.Contract#getService <em>Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Service</em>'.
	 * @see ocl_final.Contract#getService()
	 * @see #getContract()
	 * @generated
	 */
	EAttribute getContract_Service();

	/**
	 * Returns the meta object for class '{@link ocl_final.Precondition <em>Precondition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Precondition</em>'.
	 * @see ocl_final.Precondition
	 * @generated
	 */
	EClass getPrecondition();

	/**
	 * Returns the meta object for the reference '{@link ocl_final.Precondition#getOperation <em>Operation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Operation</em>'.
	 * @see ocl_final.Precondition#getOperation()
	 * @see #getPrecondition()
	 * @generated
	 */
	EReference getPrecondition_Operation();

	/**
	 * Returns the meta object for class '{@link ocl_final.Postcondition <em>Postcondition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Postcondition</em>'.
	 * @see ocl_final.Postcondition
	 * @generated
	 */
	EClass getPostcondition();

	/**
	 * Returns the meta object for the reference '{@link ocl_final.Postcondition#getOperation <em>Operation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Operation</em>'.
	 * @see ocl_final.Postcondition#getOperation()
	 * @see #getPostcondition()
	 * @generated
	 */
	EReference getPostcondition_Operation();

	/**
	 * Returns the meta object for class '{@link ocl_final.OpWithReturnLink <em>Op With Return Link</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Op With Return Link</em>'.
	 * @see ocl_final.OpWithReturnLink
	 * @generated
	 */
	EClass getOpWithReturnLink();

	/**
	 * Returns the meta object for class '{@link ocl_final.FindObject <em>Find Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Find Object</em>'.
	 * @see ocl_final.FindObject
	 * @generated
	 */
	EClass getFindObject();

	/**
	 * Returns the meta object for the reference list '{@link ocl_final.FindObject#getCondition <em>Condition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Condition</em>'.
	 * @see ocl_final.FindObject#getCondition()
	 * @see #getFindObject()
	 * @generated
	 */
	EReference getFindObject_Condition();

	/**
	 * Returns the meta object for class '{@link ocl_final.FindObjects <em>Find Objects</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Find Objects</em>'.
	 * @see ocl_final.FindObjects
	 * @generated
	 */
	EClass getFindObjects();

	/**
	 * Returns the meta object for the reference list '{@link ocl_final.FindObjects#getCondition <em>Condition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Condition</em>'.
	 * @see ocl_final.FindObjects#getCondition()
	 * @see #getFindObjects()
	 * @generated
	 */
	EReference getFindObjects_Condition();

	/**
	 * Returns the meta object for class '{@link ocl_final.Compare <em>Compare</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Compare</em>'.
	 * @see ocl_final.Compare
	 * @generated
	 */
	EClass getCompare();

	/**
	 * Returns the meta object for the attribute '{@link ocl_final.Compare#getOp <em>Op</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Op</em>'.
	 * @see ocl_final.Compare#getOp()
	 * @see #getCompare()
	 * @generated
	 */
	EAttribute getCompare_Op();

	/**
	 * Returns the meta object for the reference '{@link ocl_final.Compare#getSubject <em>Subject</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Subject</em>'.
	 * @see ocl_final.Compare#getSubject()
	 * @see #getCompare()
	 * @generated
	 */
	EReference getCompare_Subject();

	/**
	 * Returns the meta object for the reference '{@link ocl_final.Compare#getObject <em>Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Object</em>'.
	 * @see ocl_final.Compare#getObject()
	 * @see #getCompare()
	 * @generated
	 */
	EReference getCompare_Object();

	/**
	 * Returns the meta object for class '{@link ocl_final.CreateObject <em>Create Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Create Object</em>'.
	 * @see ocl_final.CreateObject
	 * @generated
	 */
	EClass getCreateObject();

	/**
	 * Returns the meta object for the attribute '{@link ocl_final.CreateObject#getObName <em>Ob Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ob Name</em>'.
	 * @see ocl_final.CreateObject#getObName()
	 * @see #getCreateObject()
	 * @generated
	 */
	EAttribute getCreateObject_ObName();

	/**
	 * Returns the meta object for class '{@link ocl_final.AddObject <em>Add Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Add Object</em>'.
	 * @see ocl_final.AddObject
	 * @generated
	 */
	EClass getAddObject();

	/**
	 * Returns the meta object for the attribute '{@link ocl_final.AddObject#getObName <em>Ob Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ob Name</em>'.
	 * @see ocl_final.AddObject#getObName()
	 * @see #getAddObject()
	 * @generated
	 */
	EAttribute getAddObject_ObName();

	/**
	 * Returns the meta object for the reference '{@link ocl_final.AddObject#getObj <em>Obj</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Obj</em>'.
	 * @see ocl_final.AddObject#getObj()
	 * @see #getAddObject()
	 * @generated
	 */
	EReference getAddObject_Obj();

	/**
	 * Returns the meta object for class '{@link ocl_final.ReleaseObject <em>Release Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Release Object</em>'.
	 * @see ocl_final.ReleaseObject
	 * @generated
	 */
	EClass getReleaseObject();

	/**
	 * Returns the meta object for the attribute '{@link ocl_final.ReleaseObject#getObName <em>Ob Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ob Name</em>'.
	 * @see ocl_final.ReleaseObject#getObName()
	 * @see #getReleaseObject()
	 * @generated
	 */
	EAttribute getReleaseObject_ObName();

	/**
	 * Returns the meta object for the reference '{@link ocl_final.ReleaseObject#getObj <em>Obj</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Obj</em>'.
	 * @see ocl_final.ReleaseObject#getObj()
	 * @see #getReleaseObject()
	 * @generated
	 */
	EReference getReleaseObject_Obj();

	/**
	 * Returns the meta object for class '{@link ocl_final.GetAttribute <em>Get Attribute</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Get Attribute</em>'.
	 * @see ocl_final.GetAttribute
	 * @generated
	 */
	EClass getGetAttribute();

	/**
	 * Returns the meta object for the attribute '{@link ocl_final.GetAttribute#getAttrName <em>Attr Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Attr Name</em>'.
	 * @see ocl_final.GetAttribute#getAttrName()
	 * @see #getGetAttribute()
	 * @generated
	 */
	EAttribute getGetAttribute_AttrName();

	/**
	 * Returns the meta object for class '{@link ocl_final.OpWithoutReturn <em>Op Without Return</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Op Without Return</em>'.
	 * @see ocl_final.OpWithoutReturn
	 * @generated
	 */
	EClass getOpWithoutReturn();

	/**
	 * Returns the meta object for class '{@link ocl_final.SetAttribute <em>Set Attribute</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Set Attribute</em>'.
	 * @see ocl_final.SetAttribute
	 * @generated
	 */
	EClass getSetAttribute();

	/**
	 * Returns the meta object for the attribute '{@link ocl_final.SetAttribute#getAttrName <em>Attr Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Attr Name</em>'.
	 * @see ocl_final.SetAttribute#getAttrName()
	 * @see #getSetAttribute()
	 * @generated
	 */
	EAttribute getSetAttribute_AttrName();

	/**
	 * Returns the meta object for the reference '{@link ocl_final.SetAttribute#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Value</em>'.
	 * @see ocl_final.SetAttribute#getValue()
	 * @see #getSetAttribute()
	 * @generated
	 */
	EReference getSetAttribute_Value();

	/**
	 * Returns the meta object for class '{@link ocl_final.FindLinkedObject <em>Find Linked Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Find Linked Object</em>'.
	 * @see ocl_final.FindLinkedObject
	 * @generated
	 */
	EClass getFindLinkedObject();

	/**
	 * Returns the meta object for the attribute '{@link ocl_final.FindLinkedObject#getObName <em>Ob Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ob Name</em>'.
	 * @see ocl_final.FindLinkedObject#getObName()
	 * @see #getFindLinkedObject()
	 * @generated
	 */
	EAttribute getFindLinkedObject_ObName();

	/**
	 * Returns the meta object for the reference list '{@link ocl_final.FindLinkedObject#getCondition <em>Condition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Condition</em>'.
	 * @see ocl_final.FindLinkedObject#getCondition()
	 * @see #getFindLinkedObject()
	 * @generated
	 */
	EReference getFindLinkedObject_Condition();

	/**
	 * Returns the meta object for class '{@link ocl_final.FindLinkedObjects <em>Find Linked Objects</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Find Linked Objects</em>'.
	 * @see ocl_final.FindLinkedObjects
	 * @generated
	 */
	EClass getFindLinkedObjects();

	/**
	 * Returns the meta object for the attribute '{@link ocl_final.FindLinkedObjects#getObName <em>Ob Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ob Name</em>'.
	 * @see ocl_final.FindLinkedObjects#getObName()
	 * @see #getFindLinkedObjects()
	 * @generated
	 */
	EAttribute getFindLinkedObjects_ObName();

	/**
	 * Returns the meta object for the reference list '{@link ocl_final.FindLinkedObjects#getCondition <em>Condition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Condition</em>'.
	 * @see ocl_final.FindLinkedObjects#getCondition()
	 * @see #getFindLinkedObjects()
	 * @generated
	 */
	EReference getFindLinkedObjects_Condition();

	/**
	 * Returns the meta object for class '{@link ocl_final.AddLinkOneToOne <em>Add Link One To One</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Add Link One To One</em>'.
	 * @see ocl_final.AddLinkOneToOne
	 * @generated
	 */
	EClass getAddLinkOneToOne();

	/**
	 * Returns the meta object for the attribute '{@link ocl_final.AddLinkOneToOne#getLinkName <em>Link Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Link Name</em>'.
	 * @see ocl_final.AddLinkOneToOne#getLinkName()
	 * @see #getAddLinkOneToOne()
	 * @generated
	 */
	EAttribute getAddLinkOneToOne_LinkName();

	/**
	 * Returns the meta object for the reference '{@link ocl_final.AddLinkOneToOne#getRef <em>Ref</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Ref</em>'.
	 * @see ocl_final.AddLinkOneToOne#getRef()
	 * @see #getAddLinkOneToOne()
	 * @generated
	 */
	EReference getAddLinkOneToOne_Ref();

	/**
	 * Returns the meta object for class '{@link ocl_final.OpWithReturnAttr <em>Op With Return Attr</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Op With Return Attr</em>'.
	 * @see ocl_final.OpWithReturnAttr
	 * @generated
	 */
	EClass getOpWithReturnAttr();

	/**
	 * Returns the meta object for class '{@link ocl_final.OpWithReturnLinks <em>Op With Return Links</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Op With Return Links</em>'.
	 * @see ocl_final.OpWithReturnLinks
	 * @generated
	 */
	EClass getOpWithReturnLinks();

	/**
	 * Returns the meta object for class '{@link ocl_final.AddLinkOneToMany <em>Add Link One To Many</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Add Link One To Many</em>'.
	 * @see ocl_final.AddLinkOneToMany
	 * @generated
	 */
	EClass getAddLinkOneToMany();

	/**
	 * Returns the meta object for the attribute '{@link ocl_final.AddLinkOneToMany#getLinkName <em>Link Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Link Name</em>'.
	 * @see ocl_final.AddLinkOneToMany#getLinkName()
	 * @see #getAddLinkOneToMany()
	 * @generated
	 */
	EAttribute getAddLinkOneToMany_LinkName();

	/**
	 * Returns the meta object for the reference '{@link ocl_final.AddLinkOneToMany#getRef <em>Ref</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Ref</em>'.
	 * @see ocl_final.AddLinkOneToMany#getRef()
	 * @see #getAddLinkOneToMany()
	 * @generated
	 */
	EReference getAddLinkOneToMany_Ref();

	/**
	 * Returns the meta object for class '{@link ocl_final.RemoveLinkOneToOne <em>Remove Link One To One</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Remove Link One To One</em>'.
	 * @see ocl_final.RemoveLinkOneToOne
	 * @generated
	 */
	EClass getRemoveLinkOneToOne();

	/**
	 * Returns the meta object for the attribute '{@link ocl_final.RemoveLinkOneToOne#getLinkName <em>Link Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Link Name</em>'.
	 * @see ocl_final.RemoveLinkOneToOne#getLinkName()
	 * @see #getRemoveLinkOneToOne()
	 * @generated
	 */
	EAttribute getRemoveLinkOneToOne_LinkName();

	/**
	 * Returns the meta object for the reference '{@link ocl_final.RemoveLinkOneToOne#getRef <em>Ref</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Ref</em>'.
	 * @see ocl_final.RemoveLinkOneToOne#getRef()
	 * @see #getRemoveLinkOneToOne()
	 * @generated
	 */
	EReference getRemoveLinkOneToOne_Ref();

	/**
	 * Returns the meta object for class '{@link ocl_final.RemoveLinkOneToMany <em>Remove Link One To Many</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Remove Link One To Many</em>'.
	 * @see ocl_final.RemoveLinkOneToMany
	 * @generated
	 */
	EClass getRemoveLinkOneToMany();

	/**
	 * Returns the meta object for the attribute '{@link ocl_final.RemoveLinkOneToMany#getLinkName <em>Link Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Link Name</em>'.
	 * @see ocl_final.RemoveLinkOneToMany#getLinkName()
	 * @see #getRemoveLinkOneToMany()
	 * @generated
	 */
	EAttribute getRemoveLinkOneToMany_LinkName();

	/**
	 * Returns the meta object for the reference '{@link ocl_final.RemoveLinkOneToMany#getRef <em>Ref</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Ref</em>'.
	 * @see ocl_final.RemoveLinkOneToMany#getRef()
	 * @see #getRemoveLinkOneToMany()
	 * @generated
	 */
	EReference getRemoveLinkOneToMany_Ref();

	/**
	 * Returns the meta object for class '{@link ocl_final.Literal <em>Literal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Literal</em>'.
	 * @see ocl_final.Literal
	 * @generated
	 */
	EClass getLiteral();

	/**
	 * Returns the meta object for the attribute '{@link ocl_final.Literal#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see ocl_final.Literal#getValue()
	 * @see #getLiteral()
	 * @generated
	 */
	EAttribute getLiteral_Value();

	/**
	 * Returns the meta object for class '{@link ocl_final.OpWithReturn <em>Op With Return</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Op With Return</em>'.
	 * @see ocl_final.OpWithReturn
	 * @generated
	 */
	EClass getOpWithReturn();

	/**
	 * Returns the meta object for class '{@link ocl_final.ThirdPartyService <em>Third Party Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Third Party Service</em>'.
	 * @see ocl_final.ThirdPartyService
	 * @generated
	 */
	EClass getThirdPartyService();

	/**
	 * Returns the meta object for the attribute '{@link ocl_final.ThirdPartyService#getServiceName <em>Service Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Service Name</em>'.
	 * @see ocl_final.ThirdPartyService#getServiceName()
	 * @see #getThirdPartyService()
	 * @generated
	 */
	EAttribute getThirdPartyService_ServiceName();

	/**
	 * Returns the meta object for the reference list '{@link ocl_final.ThirdPartyService#getParam <em>Param</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Param</em>'.
	 * @see ocl_final.ThirdPartyService#getParam()
	 * @see #getThirdPartyService()
	 * @generated
	 */
	EReference getThirdPartyService_Param();

	/**
	 * Returns the meta object for class '{@link ocl_final.OCLIsUndefined <em>OCL Is Undefined</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>OCL Is Undefined</em>'.
	 * @see ocl_final.OCLIsUndefined
	 * @generated
	 */
	EClass getOCLIsUndefined();

	/**
	 * Returns the meta object for the attribute '{@link ocl_final.OCLIsUndefined#getSubject <em>Subject</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Subject</em>'.
	 * @see ocl_final.OCLIsUndefined#getSubject()
	 * @see #getOCLIsUndefined()
	 * @generated
	 */
	EAttribute getOCLIsUndefined_Subject();

	/**
	 * Returns the meta object for class '{@link ocl_final.NotEmpty <em>Not Empty</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Not Empty</em>'.
	 * @see ocl_final.NotEmpty
	 * @generated
	 */
	EClass getNotEmpty();

	/**
	 * Returns the meta object for the attribute '{@link ocl_final.NotEmpty#getSubject <em>Subject</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Subject</em>'.
	 * @see ocl_final.NotEmpty#getSubject()
	 * @see #getNotEmpty()
	 * @generated
	 */
	EAttribute getNotEmpty_Subject();

	/**
	 * Returns the meta object for class '{@link ocl_final.SetReturn <em>Set Return</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Set Return</em>'.
	 * @see ocl_final.SetReturn
	 * @generated
	 */
	EClass getSetReturn();

	/**
	 * Returns the meta object for the attribute '{@link ocl_final.SetReturn#getReturn <em>Return</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Return</em>'.
	 * @see ocl_final.SetReturn#getReturn()
	 * @see #getSetReturn()
	 * @generated
	 */
	EAttribute getSetReturn_Return();

	/**
	 * Returns the meta object for class '{@link ocl_final.Operation <em>Operation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Operation</em>'.
	 * @see ocl_final.Operation
	 * @generated
	 */
	EClass getOperation();

	/**
	 * Returns the meta object for the reference '{@link ocl_final.Operation#getPrev_conj <em>Prev conj</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Prev conj</em>'.
	 * @see ocl_final.Operation#getPrev_conj()
	 * @see #getOperation()
	 * @generated
	 */
	EReference getOperation_Prev_conj();

	/**
	 * Returns the meta object for the reference '{@link ocl_final.Operation#getNext_conj <em>Next conj</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Next conj</em>'.
	 * @see ocl_final.Operation#getNext_conj()
	 * @see #getOperation()
	 * @generated
	 */
	EReference getOperation_Next_conj();

	/**
	 * Returns the meta object for class '{@link ocl_final.IfExpression <em>If Expression</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>If Expression</em>'.
	 * @see ocl_final.IfExpression
	 * @generated
	 */
	EClass getIfExpression();

	/**
	 * Returns the meta object for class '{@link ocl_final.ForAll <em>For All</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>For All</em>'.
	 * @see ocl_final.ForAll
	 * @generated
	 */
	EClass getForAll();

	/**
	 * Returns the meta object for the attribute '{@link ocl_final.ForAll#getSubject <em>Subject</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Subject</em>'.
	 * @see ocl_final.ForAll#getSubject()
	 * @see #getForAll()
	 * @generated
	 */
	EAttribute getForAll_Subject();

	/**
	 * Returns the meta object for class '{@link ocl_final.Condition <em>Condition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Condition</em>'.
	 * @see ocl_final.Condition
	 * @generated
	 */
	EClass getCondition();

	/**
	 * Returns the meta object for the reference '{@link ocl_final.Condition#getOperation <em>Operation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Operation</em>'.
	 * @see ocl_final.Condition#getOperation()
	 * @see #getCondition()
	 * @generated
	 */
	EReference getCondition_Operation();

	/**
	 * Returns the meta object for the reference '{@link ocl_final.Condition#getIfexpression <em>Ifexpression</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Ifexpression</em>'.
	 * @see ocl_final.Condition#getIfexpression()
	 * @see #getCondition()
	 * @generated
	 */
	EReference getCondition_Ifexpression();

	/**
	 * Returns the meta object for class '{@link ocl_final.Then <em>Then</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Then</em>'.
	 * @see ocl_final.Then
	 * @generated
	 */
	EClass getThen();

	/**
	 * Returns the meta object for the reference '{@link ocl_final.Then#getOperation <em>Operation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Operation</em>'.
	 * @see ocl_final.Then#getOperation()
	 * @see #getThen()
	 * @generated
	 */
	EReference getThen_Operation();

	/**
	 * Returns the meta object for the reference '{@link ocl_final.Then#getIfexpression <em>Ifexpression</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Ifexpression</em>'.
	 * @see ocl_final.Then#getIfexpression()
	 * @see #getThen()
	 * @generated
	 */
	EReference getThen_Ifexpression();

	/**
	 * Returns the meta object for class '{@link ocl_final.Else <em>Else</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Else</em>'.
	 * @see ocl_final.Else
	 * @generated
	 */
	EClass getElse();

	/**
	 * Returns the meta object for the reference '{@link ocl_final.Else#getOperation <em>Operation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Operation</em>'.
	 * @see ocl_final.Else#getOperation()
	 * @see #getElse()
	 * @generated
	 */
	EReference getElse_Operation();

	/**
	 * Returns the meta object for the reference '{@link ocl_final.Else#getIfexpression <em>Ifexpression</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Ifexpression</em>'.
	 * @see ocl_final.Else#getIfexpression()
	 * @see #getElse()
	 * @generated
	 */
	EReference getElse_Ifexpression();

	/**
	 * Returns the meta object for class '{@link ocl_final.BasicElement <em>Basic Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Basic Element</em>'.
	 * @see ocl_final.BasicElement
	 * @generated
	 */
	EClass getBasicElement();

	/**
	 * Returns the meta object for class '{@link ocl_final.Conjunction <em>Conjunction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Conjunction</em>'.
	 * @see ocl_final.Conjunction
	 * @generated
	 */
	EClass getConjunction();

	/**
	 * Returns the meta object for the attribute '{@link ocl_final.Conjunction#getOp <em>Op</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Op</em>'.
	 * @see ocl_final.Conjunction#getOp()
	 * @see #getConjunction()
	 * @generated
	 */
	EAttribute getConjunction_Op();

	/**
	 * Returns the meta object for the reference '{@link ocl_final.Conjunction#getPrev <em>Prev</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Prev</em>'.
	 * @see ocl_final.Conjunction#getPrev()
	 * @see #getConjunction()
	 * @generated
	 */
	EReference getConjunction_Prev();

	/**
	 * Returns the meta object for the reference '{@link ocl_final.Conjunction#getNext <em>Next</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Next</em>'.
	 * @see ocl_final.Conjunction#getNext()
	 * @see #getConjunction()
	 * @generated
	 */
	EReference getConjunction_Next();

	/**
	 * Returns the meta object for enum '{@link ocl_final.CompareType <em>Compare Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Compare Type</em>'.
	 * @see ocl_final.CompareType
	 * @generated
	 */
	EEnum getCompareType();

	/**
	 * Returns the meta object for enum '{@link ocl_final.LogicOperation <em>Logic Operation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Logic Operation</em>'.
	 * @see ocl_final.LogicOperation
	 * @generated
	 */
	EEnum getLogicOperation();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	Ocl_finalFactory getOcl_finalFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link ocl_final.impl.OCLImpl <em>OCL</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.OCLImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getOCL()
		 * @generated
		 */
		EClass OCL = eINSTANCE.getOCL();

		/**
		 * The meta object literal for the '<em><b>Basicelement</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OCL__BASICELEMENT = eINSTANCE.getOCL_Basicelement();

		/**
		 * The meta object literal for the '<em><b>Operation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OCL__OPERATION = eINSTANCE.getOCL_Operation();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.ContractImpl <em>Contract</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.ContractImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getContract()
		 * @generated
		 */
		EClass CONTRACT = eINSTANCE.getContract();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTRACT__NAME = eINSTANCE.getContract_Name();

		/**
		 * The meta object literal for the '<em><b>Postcondition</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONTRACT__POSTCONDITION = eINSTANCE.getContract_Postcondition();

		/**
		 * The meta object literal for the '<em><b>Precondition</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONTRACT__PRECONDITION = eINSTANCE.getContract_Precondition();

		/**
		 * The meta object literal for the '<em><b>Service</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTRACT__SERVICE = eINSTANCE.getContract_Service();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.PreconditionImpl <em>Precondition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.PreconditionImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getPrecondition()
		 * @generated
		 */
		EClass PRECONDITION = eINSTANCE.getPrecondition();

		/**
		 * The meta object literal for the '<em><b>Operation</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRECONDITION__OPERATION = eINSTANCE.getPrecondition_Operation();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.PostconditionImpl <em>Postcondition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.PostconditionImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getPostcondition()
		 * @generated
		 */
		EClass POSTCONDITION = eINSTANCE.getPostcondition();

		/**
		 * The meta object literal for the '<em><b>Operation</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference POSTCONDITION__OPERATION = eINSTANCE.getPostcondition_Operation();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.OpWithReturnLinkImpl <em>Op With Return Link</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.OpWithReturnLinkImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getOpWithReturnLink()
		 * @generated
		 */
		EClass OP_WITH_RETURN_LINK = eINSTANCE.getOpWithReturnLink();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.FindObjectImpl <em>Find Object</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.FindObjectImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getFindObject()
		 * @generated
		 */
		EClass FIND_OBJECT = eINSTANCE.getFindObject();

		/**
		 * The meta object literal for the '<em><b>Condition</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FIND_OBJECT__CONDITION = eINSTANCE.getFindObject_Condition();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.FindObjectsImpl <em>Find Objects</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.FindObjectsImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getFindObjects()
		 * @generated
		 */
		EClass FIND_OBJECTS = eINSTANCE.getFindObjects();

		/**
		 * The meta object literal for the '<em><b>Condition</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FIND_OBJECTS__CONDITION = eINSTANCE.getFindObjects_Condition();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.CompareImpl <em>Compare</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.CompareImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getCompare()
		 * @generated
		 */
		EClass COMPARE = eINSTANCE.getCompare();

		/**
		 * The meta object literal for the '<em><b>Op</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COMPARE__OP = eINSTANCE.getCompare_Op();

		/**
		 * The meta object literal for the '<em><b>Subject</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COMPARE__SUBJECT = eINSTANCE.getCompare_Subject();

		/**
		 * The meta object literal for the '<em><b>Object</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COMPARE__OBJECT = eINSTANCE.getCompare_Object();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.CreateObjectImpl <em>Create Object</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.CreateObjectImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getCreateObject()
		 * @generated
		 */
		EClass CREATE_OBJECT = eINSTANCE.getCreateObject();

		/**
		 * The meta object literal for the '<em><b>Ob Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CREATE_OBJECT__OB_NAME = eINSTANCE.getCreateObject_ObName();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.AddObjectImpl <em>Add Object</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.AddObjectImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getAddObject()
		 * @generated
		 */
		EClass ADD_OBJECT = eINSTANCE.getAddObject();

		/**
		 * The meta object literal for the '<em><b>Ob Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ADD_OBJECT__OB_NAME = eINSTANCE.getAddObject_ObName();

		/**
		 * The meta object literal for the '<em><b>Obj</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ADD_OBJECT__OBJ = eINSTANCE.getAddObject_Obj();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.ReleaseObjectImpl <em>Release Object</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.ReleaseObjectImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getReleaseObject()
		 * @generated
		 */
		EClass RELEASE_OBJECT = eINSTANCE.getReleaseObject();

		/**
		 * The meta object literal for the '<em><b>Ob Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RELEASE_OBJECT__OB_NAME = eINSTANCE.getReleaseObject_ObName();

		/**
		 * The meta object literal for the '<em><b>Obj</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RELEASE_OBJECT__OBJ = eINSTANCE.getReleaseObject_Obj();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.GetAttributeImpl <em>Get Attribute</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.GetAttributeImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getGetAttribute()
		 * @generated
		 */
		EClass GET_ATTRIBUTE = eINSTANCE.getGetAttribute();

		/**
		 * The meta object literal for the '<em><b>Attr Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GET_ATTRIBUTE__ATTR_NAME = eINSTANCE.getGetAttribute_AttrName();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.OpWithoutReturnImpl <em>Op Without Return</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.OpWithoutReturnImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getOpWithoutReturn()
		 * @generated
		 */
		EClass OP_WITHOUT_RETURN = eINSTANCE.getOpWithoutReturn();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.SetAttributeImpl <em>Set Attribute</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.SetAttributeImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getSetAttribute()
		 * @generated
		 */
		EClass SET_ATTRIBUTE = eINSTANCE.getSetAttribute();

		/**
		 * The meta object literal for the '<em><b>Attr Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SET_ATTRIBUTE__ATTR_NAME = eINSTANCE.getSetAttribute_AttrName();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SET_ATTRIBUTE__VALUE = eINSTANCE.getSetAttribute_Value();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.FindLinkedObjectImpl <em>Find Linked Object</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.FindLinkedObjectImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getFindLinkedObject()
		 * @generated
		 */
		EClass FIND_LINKED_OBJECT = eINSTANCE.getFindLinkedObject();

		/**
		 * The meta object literal for the '<em><b>Ob Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FIND_LINKED_OBJECT__OB_NAME = eINSTANCE.getFindLinkedObject_ObName();

		/**
		 * The meta object literal for the '<em><b>Condition</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FIND_LINKED_OBJECT__CONDITION = eINSTANCE.getFindLinkedObject_Condition();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.FindLinkedObjectsImpl <em>Find Linked Objects</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.FindLinkedObjectsImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getFindLinkedObjects()
		 * @generated
		 */
		EClass FIND_LINKED_OBJECTS = eINSTANCE.getFindLinkedObjects();

		/**
		 * The meta object literal for the '<em><b>Ob Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FIND_LINKED_OBJECTS__OB_NAME = eINSTANCE.getFindLinkedObjects_ObName();

		/**
		 * The meta object literal for the '<em><b>Condition</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FIND_LINKED_OBJECTS__CONDITION = eINSTANCE.getFindLinkedObjects_Condition();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.AddLinkOneToOneImpl <em>Add Link One To One</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.AddLinkOneToOneImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getAddLinkOneToOne()
		 * @generated
		 */
		EClass ADD_LINK_ONE_TO_ONE = eINSTANCE.getAddLinkOneToOne();

		/**
		 * The meta object literal for the '<em><b>Link Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ADD_LINK_ONE_TO_ONE__LINK_NAME = eINSTANCE.getAddLinkOneToOne_LinkName();

		/**
		 * The meta object literal for the '<em><b>Ref</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ADD_LINK_ONE_TO_ONE__REF = eINSTANCE.getAddLinkOneToOne_Ref();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.OpWithReturnAttrImpl <em>Op With Return Attr</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.OpWithReturnAttrImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getOpWithReturnAttr()
		 * @generated
		 */
		EClass OP_WITH_RETURN_ATTR = eINSTANCE.getOpWithReturnAttr();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.OpWithReturnLinksImpl <em>Op With Return Links</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.OpWithReturnLinksImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getOpWithReturnLinks()
		 * @generated
		 */
		EClass OP_WITH_RETURN_LINKS = eINSTANCE.getOpWithReturnLinks();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.AddLinkOneToManyImpl <em>Add Link One To Many</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.AddLinkOneToManyImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getAddLinkOneToMany()
		 * @generated
		 */
		EClass ADD_LINK_ONE_TO_MANY = eINSTANCE.getAddLinkOneToMany();

		/**
		 * The meta object literal for the '<em><b>Link Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ADD_LINK_ONE_TO_MANY__LINK_NAME = eINSTANCE.getAddLinkOneToMany_LinkName();

		/**
		 * The meta object literal for the '<em><b>Ref</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ADD_LINK_ONE_TO_MANY__REF = eINSTANCE.getAddLinkOneToMany_Ref();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.RemoveLinkOneToOneImpl <em>Remove Link One To One</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.RemoveLinkOneToOneImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getRemoveLinkOneToOne()
		 * @generated
		 */
		EClass REMOVE_LINK_ONE_TO_ONE = eINSTANCE.getRemoveLinkOneToOne();

		/**
		 * The meta object literal for the '<em><b>Link Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REMOVE_LINK_ONE_TO_ONE__LINK_NAME = eINSTANCE.getRemoveLinkOneToOne_LinkName();

		/**
		 * The meta object literal for the '<em><b>Ref</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REMOVE_LINK_ONE_TO_ONE__REF = eINSTANCE.getRemoveLinkOneToOne_Ref();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.RemoveLinkOneToManyImpl <em>Remove Link One To Many</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.RemoveLinkOneToManyImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getRemoveLinkOneToMany()
		 * @generated
		 */
		EClass REMOVE_LINK_ONE_TO_MANY = eINSTANCE.getRemoveLinkOneToMany();

		/**
		 * The meta object literal for the '<em><b>Link Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REMOVE_LINK_ONE_TO_MANY__LINK_NAME = eINSTANCE.getRemoveLinkOneToMany_LinkName();

		/**
		 * The meta object literal for the '<em><b>Ref</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REMOVE_LINK_ONE_TO_MANY__REF = eINSTANCE.getRemoveLinkOneToMany_Ref();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.LiteralImpl <em>Literal</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.LiteralImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getLiteral()
		 * @generated
		 */
		EClass LITERAL = eINSTANCE.getLiteral();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LITERAL__VALUE = eINSTANCE.getLiteral_Value();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.OpWithReturnImpl <em>Op With Return</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.OpWithReturnImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getOpWithReturn()
		 * @generated
		 */
		EClass OP_WITH_RETURN = eINSTANCE.getOpWithReturn();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.ThirdPartyServiceImpl <em>Third Party Service</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.ThirdPartyServiceImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getThirdPartyService()
		 * @generated
		 */
		EClass THIRD_PARTY_SERVICE = eINSTANCE.getThirdPartyService();

		/**
		 * The meta object literal for the '<em><b>Service Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute THIRD_PARTY_SERVICE__SERVICE_NAME = eINSTANCE.getThirdPartyService_ServiceName();

		/**
		 * The meta object literal for the '<em><b>Param</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference THIRD_PARTY_SERVICE__PARAM = eINSTANCE.getThirdPartyService_Param();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.OCLIsUndefinedImpl <em>OCL Is Undefined</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.OCLIsUndefinedImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getOCLIsUndefined()
		 * @generated
		 */
		EClass OCL_IS_UNDEFINED = eINSTANCE.getOCLIsUndefined();

		/**
		 * The meta object literal for the '<em><b>Subject</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OCL_IS_UNDEFINED__SUBJECT = eINSTANCE.getOCLIsUndefined_Subject();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.NotEmptyImpl <em>Not Empty</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.NotEmptyImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getNotEmpty()
		 * @generated
		 */
		EClass NOT_EMPTY = eINSTANCE.getNotEmpty();

		/**
		 * The meta object literal for the '<em><b>Subject</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NOT_EMPTY__SUBJECT = eINSTANCE.getNotEmpty_Subject();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.SetReturnImpl <em>Set Return</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.SetReturnImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getSetReturn()
		 * @generated
		 */
		EClass SET_RETURN = eINSTANCE.getSetReturn();

		/**
		 * The meta object literal for the '<em><b>Return</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SET_RETURN__RETURN = eINSTANCE.getSetReturn_Return();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.OperationImpl <em>Operation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.OperationImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getOperation()
		 * @generated
		 */
		EClass OPERATION = eINSTANCE.getOperation();

		/**
		 * The meta object literal for the '<em><b>Prev conj</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OPERATION__PREV_CONJ = eINSTANCE.getOperation_Prev_conj();

		/**
		 * The meta object literal for the '<em><b>Next conj</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OPERATION__NEXT_CONJ = eINSTANCE.getOperation_Next_conj();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.IfExpressionImpl <em>If Expression</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.IfExpressionImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getIfExpression()
		 * @generated
		 */
		EClass IF_EXPRESSION = eINSTANCE.getIfExpression();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.ForAllImpl <em>For All</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.ForAllImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getForAll()
		 * @generated
		 */
		EClass FOR_ALL = eINSTANCE.getForAll();

		/**
		 * The meta object literal for the '<em><b>Subject</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FOR_ALL__SUBJECT = eINSTANCE.getForAll_Subject();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.ConditionImpl <em>Condition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.ConditionImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getCondition()
		 * @generated
		 */
		EClass CONDITION = eINSTANCE.getCondition();

		/**
		 * The meta object literal for the '<em><b>Operation</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONDITION__OPERATION = eINSTANCE.getCondition_Operation();

		/**
		 * The meta object literal for the '<em><b>Ifexpression</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONDITION__IFEXPRESSION = eINSTANCE.getCondition_Ifexpression();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.ThenImpl <em>Then</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.ThenImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getThen()
		 * @generated
		 */
		EClass THEN = eINSTANCE.getThen();

		/**
		 * The meta object literal for the '<em><b>Operation</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference THEN__OPERATION = eINSTANCE.getThen_Operation();

		/**
		 * The meta object literal for the '<em><b>Ifexpression</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference THEN__IFEXPRESSION = eINSTANCE.getThen_Ifexpression();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.ElseImpl <em>Else</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.ElseImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getElse()
		 * @generated
		 */
		EClass ELSE = eINSTANCE.getElse();

		/**
		 * The meta object literal for the '<em><b>Operation</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ELSE__OPERATION = eINSTANCE.getElse_Operation();

		/**
		 * The meta object literal for the '<em><b>Ifexpression</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ELSE__IFEXPRESSION = eINSTANCE.getElse_Ifexpression();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.BasicElementImpl <em>Basic Element</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.BasicElementImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getBasicElement()
		 * @generated
		 */
		EClass BASIC_ELEMENT = eINSTANCE.getBasicElement();

		/**
		 * The meta object literal for the '{@link ocl_final.impl.ConjunctionImpl <em>Conjunction</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.impl.ConjunctionImpl
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getConjunction()
		 * @generated
		 */
		EClass CONJUNCTION = eINSTANCE.getConjunction();

		/**
		 * The meta object literal for the '<em><b>Op</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONJUNCTION__OP = eINSTANCE.getConjunction_Op();

		/**
		 * The meta object literal for the '<em><b>Prev</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONJUNCTION__PREV = eINSTANCE.getConjunction_Prev();

		/**
		 * The meta object literal for the '<em><b>Next</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONJUNCTION__NEXT = eINSTANCE.getConjunction_Next();

		/**
		 * The meta object literal for the '{@link ocl_final.CompareType <em>Compare Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.CompareType
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getCompareType()
		 * @generated
		 */
		EEnum COMPARE_TYPE = eINSTANCE.getCompareType();

		/**
		 * The meta object literal for the '{@link ocl_final.LogicOperation <em>Logic Operation</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ocl_final.LogicOperation
		 * @see ocl_final.impl.Ocl_finalPackageImpl#getLogicOperation()
		 * @generated
		 */
		EEnum LOGIC_OPERATION = eINSTANCE.getLogicOperation();

	}

} //Ocl_finalPackage
