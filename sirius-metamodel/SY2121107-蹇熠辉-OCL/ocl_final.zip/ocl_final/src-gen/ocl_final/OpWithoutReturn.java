/**
 */
package ocl_final;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Op Without Return</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ocl_final.Ocl_finalPackage#getOpWithoutReturn()
 * @model abstract="true"
 * @generated
 */
public interface OpWithoutReturn extends Operation {
} // OpWithoutReturn
