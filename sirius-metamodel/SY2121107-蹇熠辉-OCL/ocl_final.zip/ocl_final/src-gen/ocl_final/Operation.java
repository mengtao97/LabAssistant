/**
 */
package ocl_final;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Operation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ocl_final.Operation#getPrev_conj <em>Prev conj</em>}</li>
 *   <li>{@link ocl_final.Operation#getNext_conj <em>Next conj</em>}</li>
 * </ul>
 *
 * @see ocl_final.Ocl_finalPackage#getOperation()
 * @model abstract="true"
 * @generated
 */
public interface Operation extends EObject {
	/**
	 * Returns the value of the '<em><b>Prev conj</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link ocl_final.Conjunction#getPrev <em>Prev</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Prev conj</em>' reference.
	 * @see #setPrev_conj(Conjunction)
	 * @see ocl_final.Ocl_finalPackage#getOperation_Prev_conj()
	 * @see ocl_final.Conjunction#getPrev
	 * @model opposite="prev"
	 * @generated
	 */
	Conjunction getPrev_conj();

	/**
	 * Sets the value of the '{@link ocl_final.Operation#getPrev_conj <em>Prev conj</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Prev conj</em>' reference.
	 * @see #getPrev_conj()
	 * @generated
	 */
	void setPrev_conj(Conjunction value);

	/**
	 * Returns the value of the '<em><b>Next conj</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link ocl_final.Conjunction#getNext <em>Next</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Next conj</em>' reference.
	 * @see #setNext_conj(Conjunction)
	 * @see ocl_final.Ocl_finalPackage#getOperation_Next_conj()
	 * @see ocl_final.Conjunction#getNext
	 * @model opposite="next"
	 * @generated
	 */
	Conjunction getNext_conj();

	/**
	 * Sets the value of the '{@link ocl_final.Operation#getNext_conj <em>Next conj</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Next conj</em>' reference.
	 * @see #getNext_conj()
	 * @generated
	 */
	void setNext_conj(Conjunction value);

} // Operation
