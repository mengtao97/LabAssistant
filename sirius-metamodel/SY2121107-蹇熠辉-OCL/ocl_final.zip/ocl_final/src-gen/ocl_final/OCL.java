/**
 */
package ocl_final;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>OCL</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ocl_final.OCL#getBasicelement <em>Basicelement</em>}</li>
 *   <li>{@link ocl_final.OCL#getOperation <em>Operation</em>}</li>
 * </ul>
 *
 * @see ocl_final.Ocl_finalPackage#getOCL()
 * @model
 * @generated
 */
public interface OCL extends EObject {
	/**
	 * Returns the value of the '<em><b>Basicelement</b></em>' containment reference list.
	 * The list contents are of type {@link ocl_final.BasicElement}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Basicelement</em>' containment reference list.
	 * @see ocl_final.Ocl_finalPackage#getOCL_Basicelement()
	 * @model containment="true"
	 * @generated
	 */
	EList<BasicElement> getBasicelement();

	/**
	 * Returns the value of the '<em><b>Operation</b></em>' containment reference list.
	 * The list contents are of type {@link ocl_final.Operation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operation</em>' containment reference list.
	 * @see ocl_final.Ocl_finalPackage#getOCL_Operation()
	 * @model containment="true"
	 * @generated
	 */
	EList<Operation> getOperation();

} // OCL
