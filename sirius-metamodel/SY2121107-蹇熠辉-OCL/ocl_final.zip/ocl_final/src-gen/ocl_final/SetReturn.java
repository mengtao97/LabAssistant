/**
 */
package ocl_final;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Set Return</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ocl_final.SetReturn#getReturn <em>Return</em>}</li>
 * </ul>
 *
 * @see ocl_final.Ocl_finalPackage#getSetReturn()
 * @model
 * @generated
 */
public interface SetReturn extends OpWithoutReturn {
	/**
	 * Returns the value of the '<em><b>Return</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Return</em>' attribute.
	 * @see #setReturn(String)
	 * @see ocl_final.Ocl_finalPackage#getSetReturn_Return()
	 * @model
	 * @generated
	 */
	String getReturn();

	/**
	 * Sets the value of the '{@link ocl_final.SetReturn#getReturn <em>Return</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Return</em>' attribute.
	 * @see #getReturn()
	 * @generated
	 */
	void setReturn(String value);

} // SetReturn
