/**
 */
package ocl_final;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Conjunction</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ocl_final.Conjunction#getOp <em>Op</em>}</li>
 *   <li>{@link ocl_final.Conjunction#getPrev <em>Prev</em>}</li>
 *   <li>{@link ocl_final.Conjunction#getNext <em>Next</em>}</li>
 * </ul>
 *
 * @see ocl_final.Ocl_finalPackage#getConjunction()
 * @model
 * @generated
 */
public interface Conjunction extends BasicElement {
	/**
	 * Returns the value of the '<em><b>Op</b></em>' attribute.
	 * The literals are from the enumeration {@link ocl_final.LogicOperation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Op</em>' attribute.
	 * @see ocl_final.LogicOperation
	 * @see #setOp(LogicOperation)
	 * @see ocl_final.Ocl_finalPackage#getConjunction_Op()
	 * @model
	 * @generated
	 */
	LogicOperation getOp();

	/**
	 * Sets the value of the '{@link ocl_final.Conjunction#getOp <em>Op</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Op</em>' attribute.
	 * @see ocl_final.LogicOperation
	 * @see #getOp()
	 * @generated
	 */
	void setOp(LogicOperation value);

	/**
	 * Returns the value of the '<em><b>Prev</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link ocl_final.Operation#getPrev_conj <em>Prev conj</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Prev</em>' reference.
	 * @see #setPrev(Operation)
	 * @see ocl_final.Ocl_finalPackage#getConjunction_Prev()
	 * @see ocl_final.Operation#getPrev_conj
	 * @model opposite="prev_conj"
	 * @generated
	 */
	Operation getPrev();

	/**
	 * Sets the value of the '{@link ocl_final.Conjunction#getPrev <em>Prev</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Prev</em>' reference.
	 * @see #getPrev()
	 * @generated
	 */
	void setPrev(Operation value);

	/**
	 * Returns the value of the '<em><b>Next</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link ocl_final.Operation#getNext_conj <em>Next conj</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Next</em>' reference.
	 * @see #setNext(Operation)
	 * @see ocl_final.Ocl_finalPackage#getConjunction_Next()
	 * @see ocl_final.Operation#getNext_conj
	 * @model opposite="next_conj"
	 * @generated
	 */
	Operation getNext();

	/**
	 * Sets the value of the '{@link ocl_final.Conjunction#getNext <em>Next</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Next</em>' reference.
	 * @see #getNext()
	 * @generated
	 */
	void setNext(Operation value);

} // Conjunction
