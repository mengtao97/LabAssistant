/**
 */
package ocl_final;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>If Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ocl_final.Ocl_finalPackage#getIfExpression()
 * @model
 * @generated
 */
public interface IfExpression extends Operation {
} // IfExpression
