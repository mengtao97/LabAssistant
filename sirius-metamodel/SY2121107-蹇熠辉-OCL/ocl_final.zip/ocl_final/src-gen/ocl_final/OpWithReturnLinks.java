/**
 */
package ocl_final;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Op With Return Links</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ocl_final.Ocl_finalPackage#getOpWithReturnLinks()
 * @model abstract="true"
 * @generated
 */
public interface OpWithReturnLinks extends OpWithReturn {
} // OpWithReturnLinks
