/**
 */
package ocl_final;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Add Link One To One</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ocl_final.AddLinkOneToOne#getLinkName <em>Link Name</em>}</li>
 *   <li>{@link ocl_final.AddLinkOneToOne#getRef <em>Ref</em>}</li>
 * </ul>
 *
 * @see ocl_final.Ocl_finalPackage#getAddLinkOneToOne()
 * @model
 * @generated
 */
public interface AddLinkOneToOne extends OpWithoutReturn {
	/**
	 * Returns the value of the '<em><b>Link Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Link Name</em>' attribute.
	 * @see #setLinkName(String)
	 * @see ocl_final.Ocl_finalPackage#getAddLinkOneToOne_LinkName()
	 * @model
	 * @generated
	 */
	String getLinkName();

	/**
	 * Sets the value of the '{@link ocl_final.AddLinkOneToOne#getLinkName <em>Link Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Link Name</em>' attribute.
	 * @see #getLinkName()
	 * @generated
	 */
	void setLinkName(String value);

	/**
	 * Returns the value of the '<em><b>Ref</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ref</em>' reference.
	 * @see #setRef(OpWithReturnLink)
	 * @see ocl_final.Ocl_finalPackage#getAddLinkOneToOne_Ref()
	 * @model
	 * @generated
	 */
	OpWithReturnLink getRef();

	/**
	 * Sets the value of the '{@link ocl_final.AddLinkOneToOne#getRef <em>Ref</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ref</em>' reference.
	 * @see #getRef()
	 * @generated
	 */
	void setRef(OpWithReturnLink value);

} // AddLinkOneToOne
