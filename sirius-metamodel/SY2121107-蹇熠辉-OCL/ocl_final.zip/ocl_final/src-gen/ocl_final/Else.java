/**
 */
package ocl_final;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Else</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ocl_final.Else#getOperation <em>Operation</em>}</li>
 *   <li>{@link ocl_final.Else#getIfexpression <em>Ifexpression</em>}</li>
 * </ul>
 *
 * @see ocl_final.Ocl_finalPackage#getElse()
 * @model
 * @generated
 */
public interface Else extends BasicElement {
	/**
	 * Returns the value of the '<em><b>Operation</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operation</em>' reference.
	 * @see #setOperation(Operation)
	 * @see ocl_final.Ocl_finalPackage#getElse_Operation()
	 * @model
	 * @generated
	 */
	Operation getOperation();

	/**
	 * Sets the value of the '{@link ocl_final.Else#getOperation <em>Operation</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Operation</em>' reference.
	 * @see #getOperation()
	 * @generated
	 */
	void setOperation(Operation value);

	/**
	 * Returns the value of the '<em><b>Ifexpression</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ifexpression</em>' reference.
	 * @see #setIfexpression(IfExpression)
	 * @see ocl_final.Ocl_finalPackage#getElse_Ifexpression()
	 * @model
	 * @generated
	 */
	IfExpression getIfexpression();

	/**
	 * Sets the value of the '{@link ocl_final.Else#getIfexpression <em>Ifexpression</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ifexpression</em>' reference.
	 * @see #getIfexpression()
	 * @generated
	 */
	void setIfexpression(IfExpression value);

} // Else
