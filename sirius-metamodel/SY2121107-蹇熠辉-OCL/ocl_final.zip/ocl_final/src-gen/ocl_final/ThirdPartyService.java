/**
 */
package ocl_final;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Third Party Service</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ocl_final.ThirdPartyService#getServiceName <em>Service Name</em>}</li>
 *   <li>{@link ocl_final.ThirdPartyService#getParam <em>Param</em>}</li>
 * </ul>
 *
 * @see ocl_final.Ocl_finalPackage#getThirdPartyService()
 * @model
 * @generated
 */
public interface ThirdPartyService extends OpWithReturn {
	/**
	 * Returns the value of the '<em><b>Service Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Service Name</em>' attribute.
	 * @see #setServiceName(String)
	 * @see ocl_final.Ocl_finalPackage#getThirdPartyService_ServiceName()
	 * @model
	 * @generated
	 */
	String getServiceName();

	/**
	 * Sets the value of the '{@link ocl_final.ThirdPartyService#getServiceName <em>Service Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Service Name</em>' attribute.
	 * @see #getServiceName()
	 * @generated
	 */
	void setServiceName(String value);

	/**
	 * Returns the value of the '<em><b>Param</b></em>' reference list.
	 * The list contents are of type {@link ocl_final.OpWithReturn}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Param</em>' reference list.
	 * @see ocl_final.Ocl_finalPackage#getThirdPartyService_Param()
	 * @model
	 * @generated
	 */
	EList<OpWithReturn> getParam();

} // ThirdPartyService
