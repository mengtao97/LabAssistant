/**
 */
package ocl_final;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Create Object</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ocl_final.CreateObject#getObName <em>Ob Name</em>}</li>
 * </ul>
 *
 * @see ocl_final.Ocl_finalPackage#getCreateObject()
 * @model
 * @generated
 */
public interface CreateObject extends OpWithoutReturn {
	/**
	 * Returns the value of the '<em><b>Ob Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ob Name</em>' attribute.
	 * @see #setObName(String)
	 * @see ocl_final.Ocl_finalPackage#getCreateObject_ObName()
	 * @model
	 * @generated
	 */
	String getObName();

	/**
	 * Sets the value of the '{@link ocl_final.CreateObject#getObName <em>Ob Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ob Name</em>' attribute.
	 * @see #getObName()
	 * @generated
	 */
	void setObName(String value);

} // CreateObject
