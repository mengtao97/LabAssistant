/**
 */
package ocl_final;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Get Attribute</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ocl_final.GetAttribute#getAttrName <em>Attr Name</em>}</li>
 * </ul>
 *
 * @see ocl_final.Ocl_finalPackage#getGetAttribute()
 * @model
 * @generated
 */
public interface GetAttribute extends OpWithReturnAttr {
	/**
	 * Returns the value of the '<em><b>Attr Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attr Name</em>' attribute.
	 * @see #setAttrName(String)
	 * @see ocl_final.Ocl_finalPackage#getGetAttribute_AttrName()
	 * @model
	 * @generated
	 */
	String getAttrName();

	/**
	 * Sets the value of the '{@link ocl_final.GetAttribute#getAttrName <em>Attr Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Attr Name</em>' attribute.
	 * @see #getAttrName()
	 * @generated
	 */
	void setAttrName(String value);

} // GetAttribute
