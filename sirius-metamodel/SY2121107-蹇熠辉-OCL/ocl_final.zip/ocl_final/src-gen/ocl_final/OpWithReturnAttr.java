/**
 */
package ocl_final;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Op With Return Attr</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ocl_final.Ocl_finalPackage#getOpWithReturnAttr()
 * @model abstract="true"
 * @generated
 */
public interface OpWithReturnAttr extends OpWithReturn {
} // OpWithReturnAttr
