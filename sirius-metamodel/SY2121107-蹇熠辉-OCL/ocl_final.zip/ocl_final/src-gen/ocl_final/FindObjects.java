/**
 */
package ocl_final;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Find Objects</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ocl_final.FindObjects#getCondition <em>Condition</em>}</li>
 * </ul>
 *
 * @see ocl_final.Ocl_finalPackage#getFindObjects()
 * @model
 * @generated
 */
public interface FindObjects extends OpWithReturnLinks {
	/**
	 * Returns the value of the '<em><b>Condition</b></em>' reference list.
	 * The list contents are of type {@link ocl_final.Compare}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Condition</em>' reference list.
	 * @see ocl_final.Ocl_finalPackage#getFindObjects_Condition()
	 * @model
	 * @generated
	 */
	EList<Compare> getCondition();

} // FindObjects
