/**
 */
package ocl_final;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Find Object</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ocl_final.FindObject#getCondition <em>Condition</em>}</li>
 * </ul>
 *
 * @see ocl_final.Ocl_finalPackage#getFindObject()
 * @model
 * @generated
 */
public interface FindObject extends OpWithReturnLink {
	/**
	 * Returns the value of the '<em><b>Condition</b></em>' reference list.
	 * The list contents are of type {@link ocl_final.Compare}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Condition</em>' reference list.
	 * @see ocl_final.Ocl_finalPackage#getFindObject_Condition()
	 * @model
	 * @generated
	 */
	EList<Compare> getCondition();

} // FindObject
