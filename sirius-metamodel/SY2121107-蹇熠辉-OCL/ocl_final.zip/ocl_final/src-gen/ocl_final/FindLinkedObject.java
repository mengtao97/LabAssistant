/**
 */
package ocl_final;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Find Linked Object</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ocl_final.FindLinkedObject#getObName <em>Ob Name</em>}</li>
 *   <li>{@link ocl_final.FindLinkedObject#getCondition <em>Condition</em>}</li>
 * </ul>
 *
 * @see ocl_final.Ocl_finalPackage#getFindLinkedObject()
 * @model
 * @generated
 */
public interface FindLinkedObject extends OpWithReturnLink {
	/**
	 * Returns the value of the '<em><b>Ob Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ob Name</em>' attribute.
	 * @see #setObName(String)
	 * @see ocl_final.Ocl_finalPackage#getFindLinkedObject_ObName()
	 * @model
	 * @generated
	 */
	String getObName();

	/**
	 * Sets the value of the '{@link ocl_final.FindLinkedObject#getObName <em>Ob Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ob Name</em>' attribute.
	 * @see #getObName()
	 * @generated
	 */
	void setObName(String value);

	/**
	 * Returns the value of the '<em><b>Condition</b></em>' reference list.
	 * The list contents are of type {@link ocl_final.Compare}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Condition</em>' reference list.
	 * @see ocl_final.Ocl_finalPackage#getFindLinkedObject_Condition()
	 * @model
	 * @generated
	 */
	EList<Compare> getCondition();

} // FindLinkedObject
