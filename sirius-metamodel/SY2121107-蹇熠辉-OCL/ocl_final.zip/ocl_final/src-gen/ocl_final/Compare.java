/**
 */
package ocl_final;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Compare</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ocl_final.Compare#getOp <em>Op</em>}</li>
 *   <li>{@link ocl_final.Compare#getSubject <em>Subject</em>}</li>
 *   <li>{@link ocl_final.Compare#getObject <em>Object</em>}</li>
 * </ul>
 *
 * @see ocl_final.Ocl_finalPackage#getCompare()
 * @model
 * @generated
 */
public interface Compare extends OpWithoutReturn {
	/**
	 * Returns the value of the '<em><b>Op</b></em>' attribute.
	 * The literals are from the enumeration {@link ocl_final.CompareType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Op</em>' attribute.
	 * @see ocl_final.CompareType
	 * @see #setOp(CompareType)
	 * @see ocl_final.Ocl_finalPackage#getCompare_Op()
	 * @model
	 * @generated
	 */
	CompareType getOp();

	/**
	 * Sets the value of the '{@link ocl_final.Compare#getOp <em>Op</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Op</em>' attribute.
	 * @see ocl_final.CompareType
	 * @see #getOp()
	 * @generated
	 */
	void setOp(CompareType value);

	/**
	 * Returns the value of the '<em><b>Subject</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Subject</em>' reference.
	 * @see #setSubject(OpWithReturnAttr)
	 * @see ocl_final.Ocl_finalPackage#getCompare_Subject()
	 * @model
	 * @generated
	 */
	OpWithReturnAttr getSubject();

	/**
	 * Sets the value of the '{@link ocl_final.Compare#getSubject <em>Subject</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Subject</em>' reference.
	 * @see #getSubject()
	 * @generated
	 */
	void setSubject(OpWithReturnAttr value);

	/**
	 * Returns the value of the '<em><b>Object</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Object</em>' reference.
	 * @see #setObject(OpWithReturnAttr)
	 * @see ocl_final.Ocl_finalPackage#getCompare_Object()
	 * @model
	 * @generated
	 */
	OpWithReturnAttr getObject();

	/**
	 * Sets the value of the '{@link ocl_final.Compare#getObject <em>Object</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Object</em>' reference.
	 * @see #getObject()
	 * @generated
	 */
	void setObject(OpWithReturnAttr value);

} // Compare
